<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateProductsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('product', function (Blueprint $table) {
            $table->id();
            
            $table->bigInteger('iduser')->unsigned();
            $table->bigInteger('idcategory')->unsigned();
            
            $table->string('name', 50);
            $table->string('use', 20);
            $table->string('state', 20);
            $table->date('date');
            $table->decimal('price', 6, 2);
            $table->longText('description');
            $table->binary('avatar');
            
            $table->timestamps();
            $table->softDeletes();
            
            $table->foreign('iduser')->references ('id')->on('user')->onDelete('cascade')->onUpdate('cascade');
            $table->foreign('idcategory')->references ('id')->on('category')->onDelete('cascade')->onUpdate('cascade');

            $table->unique(['iduser', 'name']);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('product');
    }
}
