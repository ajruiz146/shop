<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateChatsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('chat', function (Blueprint $table) {
            $table->id();

            $table->bigInteger('idemisor')->unsigned();
            $table->bigInteger('idreceptor')->unsigned();
            $table->bigInteger('idproduct')->unsigned();
            $table->string('message', 150);

            $table->timestamps();


            $table->foreign('idemisor')->references('id')->on('user')->onDelete('cascade')->onUpdate('cascade');
            $table->foreign('idreceptor')->references('id')->on('user')->onDelete('cascade')->onUpdate('cascade');
            $table->foreign('idproduct')->references('id')->on('product')->onDelete('cascade')->onUpdate('cascade');

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('chat');
    }
}
