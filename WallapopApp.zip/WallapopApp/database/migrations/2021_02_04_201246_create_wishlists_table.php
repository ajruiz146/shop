<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateWishlistsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('wishlist', function (Blueprint $table) {
            $table->id();
            $table->bigInteger('iduser')->unsigned();
            $table->bigInteger('idproduct')->unsigned();
            $table->timestamps();

            $table->foreign('iduser')->references ('id')->on('user')->onDelete('cascade')->onUpdate('cascade');
            $table->foreign('idproduct')->references ('id')->on('product')->onDelete('cascade')->onUpdate('cascade');

            $table->unique(['iduser', 'idproduct']);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('wishlist');
    }
}
