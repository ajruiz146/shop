<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Product extends Model
{
    use HasFactory;
    use SoftDeletes;
    
    protected $table = 'product';
    
    protected $fillable = [
        'iduser',
        'idcategory',
        'name',
        'use',
        'state',
        'date',
        'price',
        'description',
        'avatar',
    ];

    public function user() {
        return $this->belongsTo('App\Models\User', 'iduser');
    }

    public function category() {
        return $this->belongsTo('App\Models\Category', 'idcategory');
    }

    public function product_images() {
        return $this->hasMany('App\Models\ProductImage', 'idproduct');
    }

    public function wishlists() {
        return $this->hasMany('App\Models\Wishlist', 'idproduct');
    }

    public function chats() {
        return $this->hasMany('App\Models\Chat', 'idproduct');
    }
}
