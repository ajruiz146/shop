<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Wishlist extends Model
{
    use HasFactory;

    protected $table = 'wishlist';

    protected $fillable = [
        'iduser',
        'idproduct',
    ];

    public function user() {
        return $this->belongsTo('App\Models\User', 'iduser');
    }

    public function product() {
        return $this->belongsTo('App\Models\Product', 'idproduct');
    }
}
