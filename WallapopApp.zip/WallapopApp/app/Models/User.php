<?php

namespace App\Models;

use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

class User extends Authenticatable implements MustVerifyEmail
{
    use HasFactory, Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $table = 'user';

    protected $fillable = [
        'name',
        'email',
        'password',
        'birthDay',
        'province',
        'description',
        'avatar',
        'authority',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password',
        'remember_token',
        'authority',
    ];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];

    public function products() {
        return $this->hasMany('App\Models\Product', 'iduser');
    }

    public function wishlists() {
        return $this->hasMany('App\Models\Wishlist', 'iduser');
    }

    public function emisors() {
        return $this->hasMany('App\Models\Chat', 'idemisor');
    }

    public function receptors() {
        return $this->hasMany('App\Models\Chat', 'idreceptor');
    }
}
