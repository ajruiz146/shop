<?php

namespace App\Http\Controllers;

use App\Models\Product;
use App\Models\Category;
use App\Models\User;
use App\Models\ProductImage;
use Session;
use DB;
use Illuminate\Http\Request;

class MarketController extends Controller
{

    public function index()
    {
        $user = auth()->user();

        $products = Product::where('iduser', '!=', $user->id);

        if(request()->category) {
            $products = Product::where('iduser', '!=', $user->id)->where('idcategory', request()->category);
        }

        if(request()->province) {
            $products = Product::select('product.id', 'product.name', 'iduser', 'idcategory', 'product.avatar', 'product.price', 'product.state')->join('user', function ($join) { 
                $join->on('product.iduser', '=', 'user.id'); 
            })->where('iduser', '!=', auth()->user()->id)->where('user.province', request()->province);	
        }
        
        /*
        if(request()->category && request()->province) {
            $products = Product::select('product.id', 'product.name', 'iduser', 'idcategory', 'product.avatar', 'product.price', 'product.state')->join('user', function ($join) { 
                $join->on('product.iduser', '=', 'user.id'); 
            })->where('iduser', '!=', auth()->user()->id)->where('user.province', request()->province)->where('idcategory', request()->category)->orderBy('idcategory');	 
        }
        */

        $parameters = ['category' => request()->category, 'province' => request()->province];
        $products = $products->paginate(10)->appends($parameters);
        


        $count = DB::select('select count(*)as number from product where idcategory in (select id from category)group by idcategory order by idcategory');
        $categories = Category::whereIn('id', Product::select('idcategory')->groupBy('idcategory'))->get();
        $provinces = DB::select('select province from user where id != :id group by province', ['id' => $user->id]);

        $args = ['products' => $products, 'categories' => $categories, 'count' => $count, 'provinces' => $provinces, 'category' => request()->category, 'province' => request()->province];
        return view('frontend.shop', $args);
    }

    public function store(Request $request) {
        //
    }
    
    public function show($id) {
        $product = Product::find($id);
        $images = ProductImage::where('idproduct', $product->id)->get();
        $products = Product::where('iduser', $product->user->id)->get();
        session()->put(['product'=> $product->id]);
        session()->put(['idproduct'=> $product->id]);
        session()->put(['idreceptor'=> $product->iduser]);
        $args = ['product' => $product, 'images' => $images, 'products' => $products];
        return view('frontend.individualshop', $args);
    }
    
    /*
    public function category($id) {
        $user = auth()->user();
        $category = Product::where('iduser', '!=', $user->id)->where('idcategory', $id)->get();
        return $this->index($category);
    }
    */
}
