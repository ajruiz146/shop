<?php

namespace App\Http\Controllers;

use App\Models\Product;
use App\Models\Category;
use App\Models\User;
use App\Models\ProductImage;
use Session;
use DB;
use Illuminate\Http\Request;

class MarketController extends Controller
{

    private function getProductList() {
        
        $user = auth()->user();
        $products = Product::where('iduser', '!=', $user->id);

        if(request()->categoryAux) {
            $products = Product::where('iduser', '!=', $user->id)->where('idcategory', request()->categoryAux);
        }

        if(request()->provinceAux) {
            $products = Product::select('product.id', 'product.name', 'iduser', 'idcategory', 'product.avatar', 'product.price', 'product.state')->join('user', function ($join) { 
                $join->on('product.iduser', '=', 'user.id'); 
            })->where('iduser', '!=', auth()->user()->id)->where('user.province', request()->provinceAux);	
        }

        if(request()->categoryAux && request()->provinceAux) {
            $products = Product::select('product.id', 'product.name', 'iduser', 'idcategory', 'product.avatar', 'product.price', 'product.state')->join('user', function ($join) { 
                $join->on('product.iduser', '=', 'user.id'); 
            })->where('iduser', '!=', auth()->user()->id)->where('user.province', request()->provinceAux)->where('idcategory', request()->categoryAux);
        }

        $rows = 6;
        if(request()->rows) {
            $rows = request()->rows;
        }
        
        $search = null;
        if(request()->search) {
            $request = request();
            $search = request()->search;
            $products = Product::where('iduser', '!=',  $user->id)
                            ->where(function ($query) use ($request) {
                                $query->where('name', 'like', '%' . $request->search . '%')
                                ->orWhere('use', 'like', '%' . $request->search . '%')
                                ->orWhere('state', 'like', '%' . $request->search . '%')
                                ->orWhere('price', 'like', '%' . $request->search . '%')
                                ->orWhere('description', 'like', '%' . $request->search . '%');
                            });   
        }
        
        $sort = 'name';
        $order = 'asc';
        
        if(request()->name) {
            $sort = 'name';
            $order = request()->name;
        }

        if(request()->price) {
            $sort = 'price';
            $order = request()->price;
        }
        
        if(request()->sort) {
            $sort = request()->sort;
        }
        
        if(request()->order) {
            $order = request()->order;
        }
        
        $end = $rows;
        $start = $end - $rows + 1;
        $total = count($products->get());

        if(request()->page) {
            $end = request()->page * $rows;
        }

        if($end > $total) {
            $end = $total;
        }
        $products = $products->orderBy($sort, $order);
        $parameters = ['category' => request()->category, 'provinceAux' => request()->provinceAux, 'search' => $search, 'rows' => $rows, 'sort' => $sort, 'order' => $order];
        $products = $products->paginate($rows)->appends($parameters);
        

        return ['products' => $products, 'search' => $search, 'rows' => $rows, 'start' => $start, 'end' => $end, 'total' => $total];
    }

    public function index()
    {

        $parameters = $this->getProductList();
        
        $count = DB::select('select count(*) as number 
                                from product
                                where iduser != :id 
                                      and deleted_at is null
                                      and idcategory in (select id from category)
                                group by idcategory 
                                order by idcategory', ['id' => auth()->user()->id]);
     
        $countAux = DB::select('select category.id 
                                    from category, product 
                                    where category.id = product.idcategory 
                                        and product.iduser != :id 
                                    group by id', ['id' => auth()->user()->id]);
        
        /*
        if(request()->provinceAux) {
            $count = DB::select('select count(*) as number, idcategory  
            from product, user
            where iduser != :id 
                  and deleted_at is null 
                  and product.iduser = user.id
                  and user.province = :province
                  and idcategory in (select id from category)
            group by idcategory 
            order by idcategory', ['id' => auth()->user()->id, 'province' => request()->provinceAux]);
        }
        dd($count);
        foreach ($countAux as $countAuxiliar) {
            
                if(in_array($countAuxiliar->id, $count)) {
                    dd('entra');
                }
            
        }
        dd($prueba);

        //dd([, $count]);
        
        if(request()->categoryAux) {
            $count = DB::select('select count(*) as number 
            from product, user
            where iduser != :id 
                  and deleted_at is null 
                  and product.iduser = user.id
                  and user.province = :province
                  and idcategory in (select id from category)
            group by idcategory 
            order by idcategory', ['id' => auth()->user()->id, 'province' => request()->provinceAux]);
        }
        */                  
        $provinces = DB::select('select province 
                                    from product, user 
                                    where iduser != :id 
                                            and deleted_at is null 
                                            and user.id = product.iduser 
                                    group by province', ['id' => auth()->user()->id]);

        $categories = Category::whereIn('id', Product::select('idcategory')
                                                        ->where('iduser', '!=', auth()->user()->id)
                                                        ->groupBy('idcategory'))
                                                        ->get();
       
        $args = array_merge(['categories' => $categories, 'count' => $count, 'provinces' => $provinces, 'categoryAux' => request()->categoryAux, 'provinceAux' => request()->provinceAux], $parameters);
        return view('frontend.shop', $args);
    }

    public function show($id) {
        
        $product = Product::find($id);
        $images = ProductImage::where('idproduct', $product->id)->get();
        $products = Product::where('iduser', $product->user->id)->get();
        
        session()->put(['product'=> $product->id]);
        session()->put(['idproduct'=> $product->id]);
        session()->put(['idreceptor'=> $product->iduser]);
            
        $args = ['product' => $product, 'images' => $images, 'products' => $products];
        return view('frontend.individualshop', $args);
    }
    
}
