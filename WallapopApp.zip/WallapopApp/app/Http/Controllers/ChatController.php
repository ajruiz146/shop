<?php

namespace App\Http\Controllers;

use App\Models\Chat;
use App\Models\User;
use Illuminate\Http\Request;

class ChatController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('frontend.chat');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        
        if(session()->has('chat')) {
            $idreceptor = session()->get('chat');
            $idproduct = session()->get('chatProduct');
            $route = explode('/', url()->previous());
            $routeid = $route[count($route)-1];
            $chat = new Chat(['idemisor' => auth()->user()->id, 'idreceptor' => $idreceptor, 'idproduct'=> $idproduct,'message' => $request->message]);
            
            try {
                $chat->save();        
            } catch (\Exception $e) {
                $e;
            }
        }

        if(session()->has('idreceptor')) {
            $idreceptor = session()->get('idreceptor');
            $idproduct = session()->get('idproduct');
            $chat = new Chat(['idemisor' => auth()->user()->id, 'idreceptor' => $idreceptor, 'idproduct'=> $idproduct,'message' => $request->message]);
            
            try {
                $chat->save();    
                $routeid = $chat->id;  
            } catch (\Exception $e) {
                $e;
            }
        }

        session()->forget('chat');
        session()->forget('chatProduct');
        return redirect('chat/' . $routeid);
    }

    public function show(Chat $chat)
    {
        
        if($chat->idemisor  == auth()->user()->id) {
            $emisorMssg = Chat::where('idemisor', auth()->user()->id)->where('idreceptor', $chat->idreceptor)->where('idproduct', $chat->idproduct)->get();        
            $receptorMssg = Chat::where('idemisor', $chat->idreceptor)->where('idreceptor', auth()->user()->id)->where('idproduct', $chat->idproduct)->get();
            session()->put(['chat'=> $chat->idreceptor]);
        } else {
            $emisorMssg = Chat::where('idemisor', $chat->idemisor)->where('idreceptor', auth()->user()->id)->where('idproduct', $chat->idproduct)->get();        
            $receptorMssg = Chat::where('idemisor', auth()->user()->id)->where('idreceptor', $chat->idemisor)->where('idproduct', $chat->idproduct)->get();
            session()->put(['chat'=> $chat->idemisor]);
        }

        $merged = $emisorMssg->merge($receptorMssg);
        $merged = $merged->sortBy('id');
        
        $emisor = auth()->user()->id;
        $receptor = $chat->idreceptor;
        
        if($chat->idemisor == auth()->user()->id) {
            $theOtherUser = User::find($chat->idreceptor);
        } else {
            $theOtherUser = User::find($chat->idemisor);
        }
        
        session()->put(['chatProduct'=> $chat->idproduct]);
        $args = ['chats' => $merged, 'emisor' => $emisor, 'receptor' => $receptor, 'theOtherUser' => $theOtherUser];
        return view('frontend.chat', $args);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Chat  $chat
     * @return \Illuminate\Http\Response
     */
    public function edit(Chat $chat)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Chat  $chat
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Chat $chat)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Chat  $chat
     * @return \Illuminate\Http\Response
     */
    public function destroy(Chat $chat)
    {
        
    }
}
