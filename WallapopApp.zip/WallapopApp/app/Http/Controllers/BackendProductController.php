<?php

namespace App\Http\Controllers;

use App\Models\Product;
use App\Models\User;
use App\Models\Category;
use App\Models\ProductImage;
use Illuminate\Http\Request;

class BackendProductController extends Controller
{

    public function edit(Product $product)
    {
        $user = User::find($product->iduser);
        $categories = Category::all();
        return view('backend.editproduct', ['product' => $product, 'user' => $user, 'categories' => $categories]);
    }

    public function update(Request $request, Product $product)
    {
        $product->fill($request->all());
        
        if($request->hasFile('image')) {   
            $images = $request->file('image');
            foreach ($images as $index => $image) { 
                $file = $image;
                $path = $file->getRealPath();    
                $avatar = file_get_contents($path);
                $base64 = base64_encode($avatar);
                $productImage = new ProductImage(['image' => $base64, 'idproduct' => $product->id]);
                $productImage->save();
            } 
        } 
        if(isset($productImage->image)) {
            $product->avatar = $productImage->image;
        }
        
        try {
           $product->save();
        } catch (\Exception $e) {
           
        }
        
        return redirect('backend/' . $product->iduser);
    }

    public function destroy(Product $product)
    {   
        if($product->user->authority === 'root' && auth()->user()->id != 'root') {
            return back();
        }

        try {
            $product->delete();
        } catch(\Exception $e) {

        }

        return redirect()->back();
    }
}
