<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Hash;
use Session;
use File;

class BackendUserController extends Controller
{

    function __construct() {
        //$this->middleware('backendaccess')->only(['create', 'store', 'destroy']);
    }
    /*
    public function index() {
        $users = User::all();
        //$user = User::find(1);
        return view('backend.index', ['users' => $users]);
    }
    */
    public function index(Request $request) {

        $user = new User();
        $order = ['id' ,'name', 'birthDay', 'province'];
        
        $rows = 5;
        if($request->input('rows')) {
            $rows = $request->input('rows');
        }
        
        $search = $request->input('search');
        if($search != null) {
            $user = $user->where('id', 'like', '%' . $search . '%')
                           ->orWhere('name', 'like', '%' . $search . '%')
                           ->orWhere('birthDay', 'like', '%' . $search . '%')
                           ->orWhere('province', 'like', '%' . $search . '%');
        }
        
        $orderby = $request->input('orderby');
        $sort = 'asc';
        
        if($orderby != null) {
            if(!isset($order[$orderby])) {
                $orderby = 0;
            }
            $orderbyField = $order[$orderby];
            if($request->input('sort') != null) {
                $sort = $request->input('sort');
                if(!($sort == 'asc' || $sort == 'desc')) {
                    $sort = 'asc';
                }
            }
            $user = $user->orderby($orderbyField, $sort);
        }

        $paginationParameters = ['search' => $search, 'orderby' => $orderby, 'sort' => $sort, 'rows' => $rows];
        
        $user = $user->orderBy('name', 'asc')->paginate($rows)->appends($paginationParameters);
        return view('backend.index', array_merge(['users' => $user], $paginationParameters));
    }

    public function create() {

        return view('backend.create');
    }

    public function store(Request $request) {
        $requestValidated = $this->createUserValidate($request->all())->validate();

        $user = new User($requestValidated); 
        
        if(auth()->user()->authority === 'admin' && $user->authority === 'root') {
            return back();
        }

        $avatar = File::get(public_path() . '\assetsBackend\images\auth\avatar.png');
        
        if($request->hasFile('avatar') && $request->file('avatar')->isValid()) {    
            $file = $request->file('avatar');  
            $path = $file->getRealPath();    
            $avatar = file_get_contents($path);   
        }
        
        $base64 = base64_encode($avatar);
        $user->avatar = $base64;
        
        $user->password = Hash::make($request->password);

        try {
            $user->save();
        } catch(\Exception $e) {
            
        }
        
        return redirect('backend');
    }

    public function show($id) {
        $user = User::find($id);
        return view('backend.show', ['user' => $user]);
    }

    public function edit($id) {
        $user = User::find($id);
        
        if(auth()->user()->authority !== 'root' && $user->authority === 'root') {
            Session::flash('noauthority', 'You dont have permission!');
            return back();
        }

        return view('backend.edit', ['user' => $user]);
    }

    public function update(Request $request, $id) {
        $user = User::find($id);
        
        $requestValidated = $this->editUserValidate($request->all(), $user)->validate();

        $auxPass = $user->password;
        
        $user->fill($requestValidated);
        
        if($request->hasFile('avatar') && $request->file('avatar')->isValid()) {    
            $file = $request->file('avatar');    
            $path = $file->getRealPath();    
            $avatar = file_get_contents($path);    
            $base64 = base64_encode($avatar);
            $user->avatar = $base64;
        } 
        
        

        if($request->password == null) {
            $user->password = $auxPass;
        } else {
            $user->password = Hash::make($requestValidated->password);
        }

        try {
           $user->save();
        } catch (\Exception $e) {
           
        }
        
        return redirect('backend');
    }

    public function destroy($id) {
        $user = User::find($id);
        
        if($user->authority === 'root') {
            return redirect('backend');
        }

        try {
            $user->delete();
        } catch(\Exception $e) {

        }

        return redirect('backend');
    }

    protected function createUserValidate(array $data)
    {
        return Validator::make($data, [

            'name'          => ['required', 'string', 'min:3', 'max:50'],
            'email'         => ['required', 'string', 'email', 'max:100', 'unique:user'],
            'password'      => ['required', 'string', 'password', 'min:8','max:50'],
            'birthDay'      => ['required', 'date', 'date_format:Y-m-d', 'before:-18 years'],
            'province'      => ['required', 'string', 'max:255'],
            'authority'     => ['required', 'string', 'min:4', 'max:5'],
            'avatar'        => ['max:64000', 'mimes:jpg,jpeg,gif,png,PNG,JPG,JPEG'],
            'description'   => ['required', 'string', 'max:255'],
        ]);
    }

    protected function editUserValidate(array $data, $user)
    {
        return Validator::make($data, [

            'name'          => ['required', 'string', 'min:3', 'max:50'],
            'email'         => ['required', 'string', 'email', 'max:100', 'unique:user,email,' . $user->id],
            'password'      => ['nullable', 'string', 'password', 'min:8','max:255'],
            'birthDay'      => ['required', 'date', 'date_format:Y-m-d', 'before:-18 years'],
            'province'      => ['required', 'string', 'max:255'],
            'authority'     => ['required', 'string', 'min:4', 'max:5'],
            'avatar'        => ['max:64000', 'mimes:jpg,jpeg,gif,png,PNG,JPG,JPEG'],
            'description'   => ['required', 'string', 'max:255'],
        ]);
    }
}
