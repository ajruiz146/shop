<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PruebaBackendController extends Controller
{
    function prueba() {
        return view('backend.index');
    }
}
