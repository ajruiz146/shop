<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Category;
use App\Models\Product;
use App\Models\Wishlist;
use App\Models\Chat;

use DB;

class HomeController extends Controller
{

    public function __construct() {
        $this->middleware('auth');
    }

    public function index() {    
        $products = Product::where('iduser', auth()->user()->id)->get();
        $categories = Category::all();
        $user = auth()->user();
        $wishlists = Wishlist::where('iduser', $user->id)->get();
        //$chats = DB::where('idemisor', auth()->user()->id)->get();

        //$query = Chat::select('idreceptor', 'idemisor', 'idproduct', 'id', 'message')->where('idreceptor', 1)->groupBy('idemisor', 'idreceptor', 'idproduct');
        //$chats = Chat::select('idemisor', 'idreceptor', 'idproduct', 'id', 'message')->where('idemisor', 1)->groupBy('idemisor', 'idreceptor', 'idproduct')->union($query)->get();
        //$prueba = DB::select('select * from chat where idemisor = 1 group by idemisor, idreceptor, idproduct');
        $chatsenviados = Chat::where('idemisor', auth()->user()->id)->groupBy('idemisor', 'idreceptor', 'idproduct')->get();
        $chatsrecibidos = Chat::where('idreceptor', auth()->user()->id)->groupBy('idemisor', 'idreceptor', 'idproduct')->get();

        //dd($chatsenviados);
        $chats = [];
        
        if(count($chatsenviados) == 0 || count($chatsrecibidos) == 0) {
            
            if(count($chatsenviados) == 0) {
                
                foreach($chatsrecibidos as $chatrecibido) { 
                    array_push($chats, $chatrecibido);
                    
                }
               
            } else if(count($chatsrecibidos) == 0) {
                
                foreach($chatsenviados as $chatenviado) { 
                    array_push($chats, $chatenviado);
                }
            }    
        }

        if(count($chatsenviados) == 1 || count($chatsrecibidos) == 1) {
            foreach($chatsrecibidos as $chatrecibido) {
                foreach($chatsenviados as $chatenviado) {
                    if($chatenviado->idemisor == $chatrecibido->idreceptor && $chatenviado->idreceptor == $chatrecibido->idemisor && $chatenviado->idproduct == $chatrecibido->idproduct) {
                        array_push($chats, $chatrecibido);
                    } else {
                        
                        array_push($chats, $chatrecibido);
                    }
                }
            }
        }

        if(count($chatsrecibidos) >= count($chatsenviados)){
            foreach($chatsrecibidos as $chatrecibido) {
                foreach($chatsenviados as $chatenviado) {
                    if($chatenviado->idemisor == $chatrecibido->idreceptor && $chatenviado->idreceptor == $chatrecibido->idemisor && $chatenviado->idproduct == $chatrecibido->idproduct) {

                    } else {
                        
                        array_push($chats, $chatrecibido);
                    }
                }
            }
        } else {
            foreach($chatsenviados as $chatenviado) {
                foreach($chatsrecibidos as $chatrecibido) {
                    if($chatenviado->idemisor == $chatrecibido->idreceptor && $chatenviado->idreceptor == $chatrecibido->idemisor && $chatenviado->idproduct == $chatrecibido->idproduct) {
                    } else {
                        array_push($chats, $chatenviado);
                    }
                }
            }
        }

        
        $chats = array_unique($chats);

        $args = ['products' => $products, 'categories' => $categories, 'user' => $user, 'wishlists' => $wishlists, 'chats' => $chats];
        return view('home', $args);
    }
}
