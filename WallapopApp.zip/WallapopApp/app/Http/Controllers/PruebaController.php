<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PruebaController extends Controller
{
    function prueba() {
        return view('frontend.shop');
    }
}
