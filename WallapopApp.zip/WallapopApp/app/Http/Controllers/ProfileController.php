<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Session;
use Hash;

class ProfileController extends Controller
{

    public function update(Request $request, $id) {
        $user = User::find($id);
        
        //$requestValidated = $this->editUserValidate($request->all(), $user)->validate();

        $auxPass = $user->password;
        
        $user->fill($request->all());
        
        if($request->hasFile('avatar') && $request->file('avatar')->isValid()) {    
            $file = $request->file('avatar');    
            $path = $file->getRealPath();    
            $avatar = file_get_contents($path);    
            $base64 = base64_encode($avatar);
            $user->avatar = $base64;
        } 
        
        

        if($request->password == null) {
            $user->password = $auxPass;
        } else {
            $user->password = Hash::make($request->password);
        }

        try {
           $user->save();
        } catch (\Exception $e) {
           
        }
        
        return redirect('backend');
    }

    public function destroy($id) {
        $user = User::find($id);

        if($user->id === auth()->user()->id && $user->authority !== 'root') {
            try {
                $user->delete();
                Session::flash('deletedAccount', true);
            } catch(\Exception $e) {
    
            }
            return redirect('login');
        }

        return redirect('home');
    }
}
