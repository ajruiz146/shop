<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Providers\RouteServiceProvider;
use App\Models\User;
use Illuminate\Foundation\Auth\RegistersUsers;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;
use Illuminate\Auth\Events\Registered;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Auth;
use File;
use Session;

class RegisterController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Register Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles the registration of new users as well as their
    | validation and creation. By default this controller uses a trait to
    | provide this functionality without requiring any additional code.
    |
    */

    use RegistersUsers;

    /**
     * Where to redirect users after registration.
     *
     * @var string
     */
    protected $redirectTo = RouteServiceProvider::HOME;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest');
    }

    /**
     * Get a validator for an incoming registration request.
     *
     * @param  array  $data
     * @return \Illuminate\Contracts\Validation\Validator
     */
    protected function validator(array $data)
    {
        
        return Validator::make($data, [
            'name'          => ['required', 'string', 'min:3', 'max:50'],
            'email'         => ['required', 'string', 'email', 'max:100', 'unique:user'],
            'password'      => ['required', 'string', 'min:8', 'max:50', 'confirmed'],
            'birthDay'      => ['required', 'date', 'date_format:Y-m-d', 'before:-18 years'],
            'province'      => ['required', 'string', 'max:255'],
            'avatar'        => ['max:64000', 'mimes:jpg,jpeg,gif,png,PNG,JPG,JPEG'],
            'description'   => ['required', 'string', 'max:255'],
        ]);
        
    }

    /**
     * Create a new user instance after a valid registration.
     *
     * @param  array  $data
     * @return \App\Models\User
     */
    protected function create(array $data)
    {
        $avatar = File::get(public_path() . '\assetsBackend\images\auth\avatar.png');
        if(isset($data['avatar'])) {
            $file = $data['avatar']; 
            $path = $file->getRealPath();  
            $avatar = file_get_contents($path);
        }
            
        $base64 = base64_encode($avatar);
        $data['avatar'] = $base64;
        
        return User::create([
            'name' => $data['name'],
            'email' => $data['email'],
            'password' => Hash::make($data['password']),
            'birthDay' => $data['birthDay'],
            'province' => $data['province'],
            'description' => $data['description'],
            'avatar' => $data['avatar'],
        ]);
    }


    public function register(Request $request)
    {
        $this->validator($request->all())->validate();
        event(new Registered($user = $this->create($request->all())));
        //$this->guard()->login($user);
        if ($response = $this->registered($request, $user)) {
            return $response;
        }
        
        Session::flash('register', true);
        return $request->wantsJson()
                    ? new JsonResponse([], 201)
                    //: redirect($this->redirectPath());
                    : redirect('login');
    }

}
