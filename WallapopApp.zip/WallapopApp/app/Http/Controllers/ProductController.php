<?php

namespace App\Http\Controllers;

use App\Models\Product;
use App\Models\ProductImage;
use App\Models\Category;
use Illuminate\Http\Request;
use File;

class ProductController extends Controller
{

    public function __construct() {
        $this->middleware('frontenduser')->only(['update', 'destroy']);
    }

    public function store(Request $request) {
        $product = new Product($request->all());
        
        $user = auth()->user();
        $product->iduser = $user->id;
        $product->date = now();
        
        $avatar = $avatar = File::get(public_path() . '\assetsBackend\images\auth\product.png');
        if($request->hasFile('image')) {
            $file = $request->file('image')[0];
            $path = $file->getRealPath();    
            $avatar = file_get_contents($path);   
        }
        
        $base64 = base64_encode($avatar);
        $product->avatar = $base64;
        
        try {
            $product->save();
        } catch (\Exception $e) {
            $e;
        }

        $images = $request->file('image');
    

        if($request->hasFile('image')) {
            foreach ($images as $index => $image) { 
                $file = $image;
                $path = $file->getRealPath();    
                $avatar = file_get_contents($path);
                $base64 = base64_encode($avatar);
                $productImage = new ProductImage(['image' => $base64, 'idproduct' => $product->id]);
                $productImage->save();
            }
        }
        $product->save();
        return redirect('home');
    }

    public function show(Product $product) {
        $images = ProductImage::where('idproduct', $product->id)->get();
        $products = Product::where('iduser', auth()->user()->id)->get();
        $categories = Category::all();
        
        $args = ['images' => $images, 'product' => $product, 'products' => $products, 'categories' => $categories];      
        return view('frontend.individual', $args);
    }

    public function update(Request $request, Product $product) {
        
        //$requestValidated = $this->editUserValidate($request->all(), $user)->validate();
        
        $product->fill($request->all());
        
        if($request->hasFile('image')) {   
            $images = $request->file('image');
            foreach ($images as $index => $image) { 
                $file = $image;
                $path = $file->getRealPath();    
                $avatar = file_get_contents($path);
                $base64 = base64_encode($avatar);
                $productImage = new ProductImage(['image' => $base64, 'idproduct' => $product->id]);
                $productImage->save();
            } 
        } 
        if(isset($productImage->image)) {
            $product->avatar = $productImage->image;
        }
        
        try {
           $product->save();
        } catch (\Exception $e) {
           
        }
        
        return redirect('home');
    }

    public function destroy(Product $product) {
        
        
        
        if($product->user->id === auth()->user()->id) {
            try {
                $product->delete();
            } catch(\Exception $e) {
    
            }
        }

        return redirect('home');
    }
}
