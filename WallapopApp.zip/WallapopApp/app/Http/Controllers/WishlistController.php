<?php

namespace App\Http\Controllers;

use App\Models\Wishlist;
use App\Models\Product;
use App\Models\ProductImage;

use Session;
use Illuminate\Http\Request;

class WishlistController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request) {
        if(session()->has('product')) {
            $product_id = session()->get('product');
            $user = auth()->user();
            $wishlist = new Wishlist(['iduser' => $user->id, 'idproduct' => $product_id]);
            try {
                $wishlist->save();
            } catch(\Exception $e) {
                
            }
        }
        session()->forget('product');
        return redirect('market/' . $product_id);
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Wishlist  $wishlist
     * @return \Illuminate\Http\Response
     */
    public function show(Wishlist $wishlist)
    {
        $images = ProductImage::where('idproduct', $wishlist->idproduct)->get();
        $products = Product::where('iduser', $wishlist->product->iduser);
        $args = ['wishlist' => $wishlist, 'images' => $images, 'products' => $products];
        return view('frontend.wishlist', $args);
    }

    public function destroy(Wishlist $wishlist) {

        if(auth()->user()->id === $wishlist->user->id) {
            try {
                $wishlist->delete();
            } catch(\Exception $e) {
    
            }
        }

        return redirect('home');
    }
}
