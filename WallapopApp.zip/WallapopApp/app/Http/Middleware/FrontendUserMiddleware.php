<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use App\Models\Product;

class FrontendUserMiddleware
{
    
    public function handle(Request $request, Closure $next)
    {
        $product = $request->product;
        $user = auth()->user();
        $userProducts = Product::where('iduser', $user->id)->pluck('id')->toArray();
        
        if(in_array($product->id, $userProducts)) {
            return $next($request);
        } else {
            return redirect('home');
        }
    }
}
