<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\BackendUserController;
use App\Http\Controllers\BackendProductController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\WishlistController;
use App\Http\Controllers\MarketController;
use App\Http\Controllers\ChatController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

//Auth::routes();
Auth::routes(['verify' => true]);

//Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');


//Route::get('prueba', [App\Http\Controllers\PruebaController::class, 'prueba'])->name('prueba');
//Route::get('pruebabackend', [App\Http\Controllers\PruebaBackendController::class, 'prueba'])->name('backend');

//Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home')->middleware('auth', 'session', 'verified');
//Route::resource('backend', BackendUserController::class, ['names' => 'backend'])->middleware(['auth', 'backendaccess', 'verified']);
//Route::resource('product', ProductController::class, ['names' => 'product'])->middleware(['auth', 'session', 'verified']);
//Route::resource('profile', ProfileController::class, ['names' => 'profile'])->middleware(['auth', 'session', 'verified']);
//Route::resource('wishlist', WishlistController::class, ['names' => 'wishlist'])->middleware(['auth', 'session', 'verified']);
//Route::resource('market', MarketController::class, ['names' => 'market'])->middleware(['auth', 'session', 'verified']);
//Route::resource('chat', ChatController::class, ['names' => 'chat'])->middleware(['auth', 'session', 'verified']);

//Route::get('market/filter/{category}', [MarketController::class, 'category'])->name('market.filter')->middleware(['auth', 'session']);


Route::resource('backend', BackendUserController::class, ['names' => 'backend'])->middleware(['auth', 'backendaccess', 'verified']);
Route::resource('backend/product', BackendProductController::class, ['names' => 'backend.product'])->middleware(['auth', 'backendaccess', 'verified']);

Route::group(['middleware' => ['auth', 'session', 'verified']], function () {
    Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
    Route::resource('product', ProductController::class, ['names' => 'product']);
    Route::resource('profile', ProfileController::class, ['names' => 'profile']);
    Route::resource('wishlist', WishlistController::class, ['names' => 'wishlist']);
    Route::resource('market', MarketController::class, ['names' => 'market']);
    Route::resource('chat', ChatController::class, ['names' => 'chat']);
});

Route::delete('product/image/{id}', [ProductController::class, 'imageDelete'])->name('product.image');