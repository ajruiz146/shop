@extends('layouts.frontend')

@section('username')

    <h5>Chat with {{ $theOtherUser->name }}<span class="chat_date"> | For: {{ $chats[0]->product->name }}</span></h5>

@endsection

@section('information')
<div class="container">
    <div class="offset-md-2 col-md-8">
        <div class="messaging">
            <div class="inbox_msg">
                <div class="mesgs">
                    <div id="msg_history" class="msg_history">
                        @foreach($chats as $chat)
                        @if($chat->idemisor == $emisor)
                        <div class="outgoing_msg">
                            <div id="sent" class="sent_msg">
                                <p>{{ $chat->message }}</p>
                                <span class="time_date">{{ $chat->created_at->format('G : i | d M') }}</span>
                            </div>
                        </div>
                        @else
                        <div class="incoming_msg">
                            <div class="incoming_msg_img"> <img src="data:image/jpeg;base64,{{ $theOtherUser->avatar }}"
                                    alt="sunil"> </div>
                            <div class="received_msg">
                                <div id="received" class="received_withd_msg">
                                    <p>{{ $chat->message }}</p>
                                    <span class="time_date">{{ $chat->created_at->format('G : i | d M') }}</span>
                                </div>
                            </div>
                        </div>
                        @endif
                        @endforeach

                    </div>
                    <form action="{{ url('chat') }}" method="post">
                        @csrf
                        <div class="type_msg">
                            <div class="input_msg_write">
                                <input id="message" name="message" type="text" class="write_msg"
                                    placeholder="Type a message" />
                                <button class="msg_send_btn" type="submit"><i class="fa fa-paper-plane-o" aria-hidden="true"></i></button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection

@section('script')

<script src="{{ url('assets/js/scroll.js') }}"></script>

@endsection
