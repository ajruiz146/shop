@extends('layouts.allProducts')

@section('product')

@foreach($products as $product)

<div class="col-4">
    <div class="product" data-aos="zoom-in" data-aos-delay="0">
    <div class="product-image mb-md-3">
        <div class="product-badge badge badge-secondary">Fresh</div><a href="{{ url('market/' . $product->id) }}">
        <div class=""><img class="img-fluid" src="data:image/jpeg;base64,{{ $product->avatar }}" style="height:260px" alt="product"/></div></a>
        <div class="product-hover-overlay">
        <div><a class="text-dark text-hover-primary mr-2" href="#">
            <svg class="svg-icon svg-icon-heavy">
                <use xlink:href="#heart-1"> </use>
            </svg></a><a class="text-dark text-hover-primary text-decoration-none" href="#" data-toggle="modal" data-target="#quickView">
            <svg class="svg-icon svg-icon-heavy">
                <use xlink:href="#expand-1"> </use>
            </svg></a></div>
        </div>
    </div>
    <div class="position-relative">
        <h3 class="text-base mb-1"><a class="text-dark" href="{{ url('market/' . $product->id) }}">{{ $product->name }}</a></h3><span class="text-gray-500 text-sm">{{ $product->state }}</span><br /><span class="text-gray-500 text-sm">{{ $product->price }}€</span>
        <div class="product-stars text-xs"><span class="text-gray-500 text-sm" style="margin-right:50px">{{ $product->user->province }}</span></div>
    </div>
    </div>
</div>

@endforeach

@endsection

@section('sidebar')
<div class="sidebar col-xl-3 col-lg-4 pr-xl-5 order-lg-1">
    
    <div class="sidebar-block px-3 px-lg-0"><a class="d-lg-none block-toggler" data-toggle="collapse" href="#categoriesMenu" aria-expanded="false" aria-controls="categoriesMenu">Product Categories<span class="block-toggler-icon"></span></a>
    <div class="expand-lg collapse" id="categoriesMenu" role="menu">
        <h5 class="sidebar-heading d-none d-lg-block">Province</h5>
        <div class="sidebar-icon-menu mt-4 mt-lg-0">  
            @foreach($categories as $index => $category)
                <div class="sidebar-icon-menu-item active" data-toggle="collapse" data-target="#subcategories_0" aria-expanded aria-controls="subcategories_0" role="menuitem"> 
                    <div class="d-flex align-items-center">
                    <svg class="svg-icon sidebar-icon">
                        <use xlink:href="#trousers-1"> </use>
                    </svg><a class="sidebar-icon-menu-link font-weight-bold mr-2" href="{{ route('market.index', ['category' => $category]) }}">{{ $category->name }}</a><span class="sidebar-icon-menu-count">{{ $count[$index]->number }}</span>
                    </div>
                </div>
            @endforeach
        </div>
    </div>
    </div>
    
    
    
    <div class="sidebar-block px-3 px-lg-0"><a class="d-lg-none block-toggler" data-toggle="collapse" href="#categoriesMenu" aria-expanded="false" aria-controls="categoriesMenu">Product Categories<span class="block-toggler-icon"></span></a>
    <div class="expand-lg collapse" id="categoriesMenu" role="menu">
        <h5 class="sidebar-heading d-none d-lg-block">Category</h5>
        <div class="sidebar-icon-menu mt-4 mt-lg-0"> 
            @foreach($provinces as $index => $province)
                <div class="sidebar-icon-menu-item active" data-toggle="collapse" data-target="#subcategories_0" aria-expanded aria-controls="subcategories_0" role="menuitem"> 
                    <div class="d-flex align-items-center">
                    <svg class="svg-icon sidebar-icon">
                        <use xlink:href="#trousers-1"> </use>
                    </svg><a class="sidebar-icon-menu-link font-weight-bold mr-2" href="{{ route('market.index', ['province' => $province->province]) }}">{{ $province->province }}</a><span class="sidebar-icon-menu-count"></span>
                    </div>
                </div>
            @endforeach
        </div>
    </div>
    </div>

</div>
@endsection