@extends('layouts.login')

@section('register')
<div class="container" style="padding-bottom: 100px">
        <div class="col-lg-8 offset-lg-2">
            <div class="card">
                <div class="card-header py-4 px-5">
                    <h5 class="mb-0">New account</h5>
                </div>
                <div class="card-body p-5">
                    <p class="lead">Not our registered customer yet?</p>
                    <p class="text-muted text-sm">With registration with us new world of Wallapop Market, fantastic products and much more opens to you! The whole process will not take you more than a minute!</p>
                    <hr class="my-4">
                    <div class="container">

                    <form method="POST" action="{{ route('register') }}" enctype="multipart/form-data">
                        @csrf

                        <div class="form-group row">
                            <label for="name" class="col-md-4 col-form-label text-md-right">{{ __('Name') }}</label>

                            <div class="col-md-6">
                                <input id="name" type="text" class="form-control @error('name') is-invalid @enderror" name="name" value="{{ old('name') }}" required autocomplete="name" autofocus>
                                @error('name')
                                    <div class="error">*{{ $message }}*</div>
                                @enderror
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="email" class="col-md-4 col-form-label text-md-right">{{ __('E-Mail Address') }}</label>

                            <div class="col-md-6">
                                <input id="email" type="email" class="form-control @error('email') is-invalid @enderror" name="email" value="{{ old('email') }}" required autocomplete="email">

                                @error('email')
                                    <div class="error">*{{ $message }}*</div>
                                @enderror
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="password" class="col-md-4 col-form-label text-md-right">{{ __('Password') }}</label>

                            <div class="col-md-6">
                                <input id="password" type="password" class="form-control @error('password') is-invalid @enderror" name="password" required autocomplete="new-password">

                                @error('password')
                                    <div class="error">*{{ $message }}*</div>
                                @enderror
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="password-confirm" class="col-md-4 col-form-label text-md-right">{{ __('Confirm Password') }}</label>

                            <div class="col-md-6">
                                <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required autocomplete="new-password">
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="birthDay" class="col-md-4 col-form-label text-md-right">Birth Day</label>

                            <div class="col-md-6">
                                <input id="birthDay" type="date" class="form-control @error('birthDay') is-invalid @enderror" name="birthDay" value="{{ old('birthDay') }}" required>

                                @error('birthDay')
                                    <div class="error">*{{ $message }}*</div>
                                @enderror
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="province" class="col-md-4 col-form-label text-md-right">Province</label>

                            <div class="col-md-6">
                                <select required name="province" id="province" class="form-control @error('province') is-invalid @enderror" required>
                                    <option value="">Select Province</option>
                                    <option value="Álava/Araba" {{ old('province') == 'Álava/Araba' ? 'selected' : '' }}>Álava/Araba</option>
                                    <option value="Albacete" {{ old('province') == 'Albacete' ? 'selected' : '' }}>Albacete</option>
                                    <option value="Alicante" {{ old('province') == 'Alicante' ? 'selected' : '' }}>Alicante</option>
                                    <option value="Almería" {{ old('province') == 'Almería' ? 'selected' : '' }}>Almería</option>
                                    <option value="Asturias" {{ old('province') == 'Asturias' ? 'selected' : '' }}>Asturias</option>
                                    <option value="Ávila" {{ old('province') == 'Ávila' ? 'selected' : '' }}>Ávila</option>
                                    <option value="Badajoz" {{ old('province') == 'Badajoz' ? 'selected' : '' }}>Badajoz</option>
                                    <option value="Baleares" {{ old('province') == 'Baleares' ? 'selected' : '' }}>Baleares</option>
                                    <option value="Barcelona" {{ old('province') == 'Barcelona' ? 'selected' : '' }}>Barcelona</option>
                                    <option value="Burgos" {{ old('province') == 'Burgos' ? 'selected' : '' }}>Burgos</option>
                                    <option value="Cáceres" {{ old('province') == 'Cáceres' ? 'selected' : '' }}>Cáceres</option>
                                    <option value="Cádiz" {{ old('province') == 'Cádiz' ? 'selected' : '' }}>Cádiz</option>
                                    <option value="Cantabria" {{ old('province') == 'Cantabria' ? 'selected' : '' }}>Cantabria</option>
                                    <option value="Castellón" {{ old('province') == 'Castellón' ? 'selected' : '' }}>Castellón</option>
                                    <option value="Ceuta" {{ old('province') == 'Ceuta' ? 'selected' : '' }}>Ceuta</option>
                                    <option value="Ciudad Real" {{ old('province') == 'Ciudad Real' ? 'selected' : '' }}>Ciudad Real</option>
                                    <option value="Córdoba" {{ old('province') == 'Córdoba' ? 'selected' : '' }}>Córdoba</option>
                                    <option value="Cuenca" {{ old('province') == 'Cuenca' ? 'selected' : '' }}>Cuenca</option>
                                    <option value="Gerona/Girona" {{ old('province') == 'Gerona/Girona' ? 'selected' : '' }}>Gerona/Girona</option>
                                    <option value="Granada" {{ old('province') == 'Granada' ? 'selected' : '' }}>Granada</option>
                                    <option value="Guadalajara" {{ old('province') == 'Guadalajara' ? 'selected' : '' }}>Guadalajara</option>
                                    <option value="Guipúzcoa/Gipuzkoa" {{ old('province') == 'Guipúzcoa/Gipuzkoa' ? 'selected' : '' }}>Guipúzcoa/Gipuzkoa</option>
                                    <option value="Huelva" {{ old('province') == 'Huelva' ? 'selected' : '' }}>Huelva</option>
                                    <option value="Huesca" {{ old('province') == 'Huesca' ? 'selected' : '' }}>Huesca</option>
                                    <option value="Jaén" {{ old('province') == 'Jaén' ? 'selected' : '' }}>Jaén</option>
                                    <option value="La Coruña/A Coruña" {{ old('province') == 'La Coruña/A Coruña' ? 'selected' : '' }}>La Coruña/A Coruña</option>
                                    <option value="La Rioja" {{ old('province') == 'La Rioja' ? 'selected' : '' }}>La Rioja</option>
                                    <option value="Las Palmas" {{ old('province') == 'Las Palmas' ? 'selected' : '' }}>Las Palmas</option>
                                    <option value="León" {{ old('province') == 'León' ? 'selected' : '' }}>León</option>
                                    <option value="Lérida/Lleida" {{ old('province') == 'Lérida/Lleida' ? 'selected' : '' }}>Lérida/Lleida</option>
                                    <option value="Lugo" {{ old('province') == 'Lugo' ? 'selected' : '' }}>Lugo</option>
                                    <option value="Madrid" {{ old('province') == 'Madrid' ? 'selected' : '' }}>Madrid</option>
                                    <option value="Málaga" {{ old('province') == 'Málaga' ? 'selected' : '' }}>Málaga</option>
                                    <option value="Melilla" {{ old('province') == 'Melilla' ? 'selected' : '' }}>Melilla</option>
                                    <option value="Murcia" {{ old('province') == 'Murcia' ? 'selected' : '' }}>Murcia</option>
                                    <option value="Navarra" {{ old('province') == 'Navarra' ? 'selected' : '' }}>Navarra</option>
                                    <option value="Orense/Ourense" {{ old('province') == 'Orense/Ourense' ? 'selected' : '' }}>Orense/Ourense</option>
                                    <option value="Palencia" {{ old('province') == 'Palencia' ? 'selected' : '' }}>Palencia</option>
                                    <option value="Pontevedra" {{ old('province') == 'Pontevedra' ? 'selected' : '' }}>Pontevedra</option>
                                    <option value="Salamanca" {{ old('province') == 'Salamanca' ? 'selected' : '' }}>Salamanca</option>
                                    <option value="Segovia" {{ old('province') == 'Segovia' ? 'selected' : '' }}>Segovia</option>
                                    <option value="Sevilla" {{ old('province') == 'Sevilla' ? 'selected' : '' }}>Sevilla</option>
                                    <option value="Soria" {{ old('province') == 'Soria' ? 'selected' : '' }}>Soria</option>
                                    <option value="Tarragona" {{ old('province') == 'Tarragona' ? 'selected' : '' }}>Tarragona</option>
                                    <option value="Tenerife" {{ old('province') == 'Tenerife' ? 'selected' : '' }}>Tenerife</option>
                                    <option value="Teruel" {{ old('province') == 'Teruel' ? 'selected' : '' }}>Teruel</option>
                                    <option value="Toledo" {{ old('province') == 'Toledo' ? 'selected' : '' }}>Toledo</option>
                                    <option value="Valencia" {{ old('province') == 'Valencia' ? 'selected' : '' }}>Valencia</option>
                                    <option value="Valladolid" {{ old('province') == 'Valladolid' ? 'selected' : '' }}>Valladolid</option>
                                    <option value="Vizcaya/Bizkaia" {{ old('province') == 'Vizcaya/Bizkaia' ? 'selected' : '' }}>Vizcaya/Bizkaia</option>
                                    <option value="Zamora" {{ old('province') == 'Zamora' ? 'selected' : '' }}>Zamora</option>
                                    <option value="Zaragoza" {{ old('province') == 'Zaragoza' ? 'selected' : '' }}>Zaragoza</option>
                                </select>
                                @error('province')
                                    <div class="error">*{{ $message }}*</div>
                                @enderror
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="description" class="col-md-4 col-form-label text-md-right">Description</label>

                            <div class="col-md-6">
                                <textarea id="description" class="form-control @error('birthDay') is-invalid @enderror" name="description" required>{{ old('description') }}</textarea>

                                @error('description')
                                    <div class="error">*{{ $message }}*</div>
                                @enderror
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="avatar" class="col-md-4 col-form-label text-md-right">Profile Pic</label>

                            <div class="col-md-6">
                                <input id="avatar" type="file" class="form-control @error('avatar') is-invalid @enderror" name="avatar">

                                @error('avatar')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>


                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    {{ __('Register') }}
                                </button>
                            </div>
                        </div>
                        
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection