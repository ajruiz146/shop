@extends('layouts.admin')

@section('users')

<div class="main-body">
    <div class="row gutters-sm">
        <div class="col-md-4 mb-3">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex flex-column align-items-center text-center">
                        <div class="card p-3 bg-white" style="margin:20px">
                            <div class="row">
                                <a style="padding-left: 20px;" href="{{ url('backend/product/' . $product->id. '/edit') }}"><i style="font-size:1.2rem;" class="feather icon-edit"></i></a>
                                <a href="javascript:void(0)" class="productDelete" data-id="{{ $product->id }}" data-name="{{ $product->name }}" data-id="{{ $user->id }}" data-name="{{ $user->name }}"><i style="padding: 3px; margin-left: 2px; font-size:1.2rem;" class="feather icon-trash-2"></i></a> 
                            </div>
                            
                            <div class="about-product text-center mt-2"><img src="data:image/jpeg;base64,{{ $product->avatar }}" width="300">
                                <div>
                                    <h4>{{ $product->name }}</h4>
                                    <h6 class="mt-0 text-black-50">{{ $product->category->name }}</h6>
                                </div>
                            </div>
                            <div class="stats mt-2">
                                <div class="d-flex justify-content-between p-price"><span>Use:</span><span>{{ $product->use }}</span></div>
                                <div class="d-flex justify-content-between p-price"><span>State:</span><span>{{ $product->state }}</span></div>
                                <div class="d-flex justify-content-between p-price"><span>Date:</span><span>{{ $product->date }}</span></div>
                            </div>
                        
                            <div class="d-flex justify-content-between total font-weight-bold mt-4"><span>Total</span><span>{{ $product->price }}€</span></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-8">
            <div class="card">
                <div class="card-body">
                    <form action="{{ url('backend/product/' . $product->id) }}" method="POST" enctype='multipart/form-data'>
                        @csrf
                        @method('put')
                        <div class="form-group">
                            <input type="hidden" class="form-control" id="iduser" name="iduser" value="{{ auth()->user()->id }}">
                        </div>

                        <div class="form-group">
                            <label for="name">Product Name</label>
                            <input type="text" class="form-control" id="name" name="name" placeholder="Enter name"
                                value="{{ old('name', $product->name) }}">
                            @error('name')
                            <div class="error">*{{ $message }}*</div>
                            @enderror
                        </div>

                        <div class="form-group">
                            <label for="rol">Category</label>
                            <select required name="idcategory" id="idcategory" class="form-control">
                                @foreach($categories as $category)
                                <option value="{{ $category->id }}" {{ $product->idcategory == $category->id ? 'selected' : '' }} {{
                                    old('idcategory') == $category->id ? 'selected' : '' }}>{{ $category->name }}</option>
                                @endforeach
                            </select>
                            @error('authority')
                            <div class="error">*{{ $message }}*</div>
                            @enderror
                        </div>

                        <div class="form-group">
                            <label for="text">Use</label>
                            <input type="text" class="form-control" id="use" name="use" placeholder="Enter use"
                                value="{{ old('use', $product->use) }}">
                            @error('use')
                            <div class="error">*{{ $message }}*</div>
                            @enderror
                        </div>


                        <div class="form-group">
                            <label for="state">State</label>
                            <input type="text" class="form-control" id="state" name="state" placeholder="State"
                                value="{{ old('state', $product->state) }}">
                            @error('state')
                            <div class="error">*{{ $message }}*</div>
                            @enderror
                        </div>


                        <div class="form-group">
                            <label for="price">Price</label>
                            <input type="text" class="form-control" id="price" name="price" placeholder="€"
                                value="{{ old('price', $product->price) }}">
                            @error('price')
                            <div class="error">*{{ $message }}*</div>
                            @enderror
                        </div>

                        <div class="form-group">
                            <label for="description">Description</label>
                            <textarea class="form-control" id="description" name="description"
                                rows="4">{{ old('description', $product->description) }}</textarea>
                            @error('description')
                            <div class="error">*{{ $message }}*</div>
                            @enderror
                        </div>

                        <div class="form-group">
                            <label for="image">Images</label> <br>
                            <input type="file" id="image" name="image[]" multiple>
                            @error('image')
                            <div class="error">*{{ $message }}*</div>
                            @enderror
                        </div>
                        <button type="submit" class="btn  btn-primary">Submit</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<form id="formDeleteShow" action="{{ url('backend/' . $user->id) }}" method="POST">
    @method('delete')
    @csrf
</form>

@endsection

@section('modal')

<div id="deleteModal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="deleteModalLiveLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="deleteModalLiveLabel">Modal Title</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            </div>
            <div class="modal-body">
                <p id="refresh">Dou you want to delete from Users List?</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn  btn-secondary" data-dismiss="modal">Close</button>
                <button id="deleteTrue" type="button" class="btn  btn-primary">Delete</button>
            </div>
        </div>
    </div>
</div>

@endsection('modal')