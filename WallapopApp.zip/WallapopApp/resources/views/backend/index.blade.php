@extends('layouts.admin')

@section('users')

<div class="card">
    <div class="card-header">
        <h5>Users Administration</h5>
    </div>
    <div class="card-body table-border-style">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>
                            Avatar
                        
                        </th>
                        <th>
                            #
                            <a href="{{ route('backend.index', ['search' => $search , 'sort' => 'asc', 'orderby' => 0]) }}">↓</a>
                            <a href="{{ route('backend.index', ['search' => $search , 'sort' => 'desc', 'orderby' => 0]) }}">↑</a>
                        </th>
                        <th>
                            Name
                            <a href="{{ route('backend.index', ['search' => $search , 'sort' => 'asc', 'orderby' => 1]) }}">↓</a>
                            <a href="{{ route('backend.index', ['search' => $search , 'sort' => 'desc', 'orderby' => 1]) }}">↑</a>
                        </th>
                        <th>
                            Birth Day
                            <a href="{{ route('backend.index', ['search' => $search , 'sort' => 'asc', 'orderby' => 2]) }}">↓</a>
                            <a href="{{ route('backend.index', ['search' => $search , 'sort' => 'desc', 'orderby' => 2]) }}">↑</a>
                        </th>
                        <th>
                            Province
                            <a href="{{ route('backend.index', ['search' => $search , 'sort' => 'asc', 'orderby' => 3]) }}">↓</a>
                            <a href="{{ route('backend.index', ['search' => $search , 'sort' => 'desc', 'orderby' => 3]) }}">↑</a>
                        </th>
                        <th>Show</th>
                        <th>Edit</th>
                        <th>Delete</th>
                    </tr>
                </thead>
                <tbody>
                @foreach($users as $user)
                    <tr>
                        <td><img class="avatar" src="data:image/jpeg;base64,{{ $user->avatar }}"></td>
                        <td>{{ $user->id }}</td>
                        <td>{{ $user->name }}</td>
                        <td>{{ $user->birthDay }}</td>
                        <td>{{ $user->province }}</td>

                        <td><a href="{{ url('backend/' . $user->id) }}"><i class="feather icon-eye"></a></td>
                        @if(Auth::user()->authority === 'admin')
                            @if($user->authority === 'root')
                            <td><a href="{{ url('backend/' . $user->id . '/edit') }}"><i style="color:grey" class="feather icon-edit"></a></td>
                            <td><a href="#" class="deleteIndex nondelete"><i style="color:grey" class="feather icon-user-x"></a></td>
                            @else
                            <td><a href="{{ url('backend/' . $user->id . '/edit') }}"><i class="feather icon-edit"></a></td>
                            <td><a href="#" data-toggle="modal" data-target="#deleteModal" data-id="{{ $user->id }}" data-name="{{ $user->name }}" class="deleteIndex"><i class="feather icon-user-x"></a></td>
                            @endif
                        @else 
                        <td><a href="{{ url('backend/' . $user->id . '/edit') }}"><i class="feather icon-edit"></a></td>
                        <td><a href="#" data-toggle="modal" data-target="#deleteModal" data-id="{{ $user->id }}" data-name="{{ $user->name }}" class="deleteIndex"><i class="feather icon-user-x"></a></td>
                        @endif
                    </tr>
                @endforeach
                </tbody>
            </table>
            
        </div>
    </div>
</div>
<div class="row">
    <div class="col-lg-6">
        {{ $users->onEachSide(2)->links() }}
    </div>
    <div class="col-lg-5">
        <div class="float-right">
            <form class="form-inline" id="formRows">
                <label for="selectRows">Select rows number: </label>
                <select name="rows" class="form-control" id="selectRows">
                    <option @if($rows==2) selected @endif>2</option>
                    <option @if($rows==3) selected @endif>3</option>
                    <option @if($rows==5) selected @endif>5</option>
                    <option @if($rows==10) selected @endif>10</option>
                </select>
                <input type="hidden" name="orderby" value="{{ $orderby }}">
                <input type="hidden" name="sort" value="{{ $sort }}">
                <input type="hidden" name="search" value="{{ $search }}">
            </form>
        </div>
    </div>
</div>


<form id="formDeleteIndex" action="" method="POST" data-url="{{ url('backend') }}">
    @method('delete')
    @csrf
</form>



@endsection

@section('modal')

<div id="deleteModal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="deleteModalLiveLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="deleteModalLiveLabel">Modal Title</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            </div>
            <div class="modal-body">
                <p id="refresh">Dou you want to delete from Users List?</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn  btn-secondary" data-dismiss="modal">Close</button>
                <button id="deleteConfirm" type="button" class="btn  btn-primary">Delete</button>
            </div>
        </div>
    </div>
</div>

@endsection



@if(Session::has('noauthority'))
    <div id="noauthority"></div>
@endif