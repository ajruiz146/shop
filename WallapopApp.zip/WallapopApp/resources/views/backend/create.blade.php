@extends('layouts.admin')

@section('users')

<div class="card">
    <div class="card-body">
        <h5>Create User</h5>
        <hr>
        <div class="row">
            <div class="col-md-6">
                <form action="{{ url('backend') }}" method="POST" enctype='multipart/form-data'>
                    @csrf

                    <div class="form-group">
                        <label for="name">Name</label>
                        <input type="text" class="form-control" id="name" name="name" placeholder="Enter name" value="{{ old('name') }}">
                        @error('name')
                            <div class="error">*{{ $message }}*</div>
                        @enderror
                    </div>
                    

                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="email" class="form-control" id="email" name="email" placeholder="Enter email" value="{{ old('email') }}">
                        @error('email')
                        <div class="error">*{{ $message }}*</div>
                        @enderror
                    </div>
                    

                    <div class="form-group">
                        <label for="password">Password</label>
                        <input type="password" class="form-control" id="password" name="password" placeholder="Password">
                        @error('password')
                        <div class="error">*{{ $message }}*</div>
                        @enderror
                    </div>
                    

                    <div class="form-group">
                        <label for="birthDay">Birth Day</label>
                        <input type="date" class="form-control" id="birthDay" name="birthDay" value="{{ old('birthDay') }}">
                        @error('birthDay')
                            <div class="error">*{{ $message }}*</div>
                        @enderror
                    </div>
                    

                    <div class="form-group">
                        <label for="province">Province</label>
                        <select required name="province" id="province" class="form-control">
                            <option value="">Select Province</option>
                            <option value="Álava/Araba" {{ old('province') == 'Álava/Araba' ? 'selected' : '' }}>Álava/Araba</option>
                            <option value="Albacete" {{ old('province') == 'Albacete' ? 'selected' : '' }}>Albacete</option>
                            <option value="Alicante" {{ old('province') == 'Alicante' ? 'selected' : '' }}>Alicante</option>
                            <option value="Almería" {{ old('province') == 'Almería' ? 'selected' : '' }}>Almería</option>
                            <option value="Asturias" {{ old('province') == 'Asturias' ? 'selected' : '' }}>Asturias</option>
                            <option value="Ávila" {{ old('province') == 'Ávila' ? 'selected' : '' }}>Ávila</option>
                            <option value="Badajoz" {{ old('province') == 'Badajoz' ? 'selected' : '' }}>Badajoz</option>
                            <option value="Baleares" {{ old('province') == 'Baleares' ? 'selected' : '' }}>Baleares</option>
                            <option value="Barcelona" {{ old('province') == 'Barcelona' ? 'selected' : '' }}>Barcelona</option>
                            <option value="Burgos" {{ old('province') == 'Burgos' ? 'selected' : '' }}>Burgos</option>
                            <option value="Cáceres" {{ old('province') == 'Cáceres' ? 'selected' : '' }}>Cáceres</option>
                            <option value="Cádiz" {{ old('province') == 'Cádiz' ? 'selected' : '' }}>Cádiz</option>
                            <option value="Cantabria" {{ old('province') == 'Cantabria' ? 'selected' : '' }}>Cantabria</option>
                            <option value="Castellón" {{ old('province') == 'Castellón' ? 'selected' : '' }}>Castellón</option>
                            <option value="Ceuta" {{ old('province') == 'Ceuta' ? 'selected' : '' }}>Ceuta</option>
                            <option value="Ciudad Real" {{ old('province') == 'Ciudad Real' ? 'selected' : '' }}>Ciudad Real</option>
                            <option value="Córdoba" {{ old('province') == 'Córdoba' ? 'selected' : '' }}>Córdoba</option>
                            <option value="Cuenca" {{ old('province') == 'Cuenca' ? 'selected' : '' }}>Cuenca</option>
                            <option value="Gerona/Girona" {{ old('province') == 'Gerona/Girona' ? 'selected' : '' }}>Gerona/Girona</option>
                            <option value="Granada" {{ old('province') == 'Granada' ? 'selected' : '' }}>Granada</option>
                            <option value="Guadalajara" {{ old('province') == 'Guadalajara' ? 'selected' : '' }}>Guadalajara</option>
                            <option value="Guipúzcoa/Gipuzkoa" {{ old('province') == 'Guipúzcoa/Gipuzkoa' ? 'selected' : '' }}>Guipúzcoa/Gipuzkoa</option>
                            <option value="Huelva" {{ old('province') == 'Huelva' ? 'selected' : '' }}>Huelva</option>
                            <option value="Huesca" {{ old('province') == 'Huesca' ? 'selected' : '' }}>Huesca</option>
                            <option value="Jaén" {{ old('province') == 'Jaén' ? 'selected' : '' }}>Jaén</option>
                            <option value="La Coruña/A Coruña" {{ old('province') == 'La Coruña/A Coruña' ? 'selected' : '' }}>La Coruña/A Coruña</option>
                            <option value="La Rioja" {{ old('province') == 'La Rioja' ? 'selected' : '' }}>La Rioja</option>
                            <option value="Las Palmas" {{ old('province') == 'Las Palmas' ? 'selected' : '' }}>Las Palmas</option>
                            <option value="León" {{ old('province') == 'León' ? 'selected' : '' }}>León</option>
                            <option value="Lérida/Lleida" {{ old('province') == 'Lérida/Lleida' ? 'selected' : '' }}>Lérida/Lleida</option>
                            <option value="Lugo" {{ old('province') == 'Lugo' ? 'selected' : '' }}>Lugo</option>
                            <option value="Madrid" {{ old('province') == 'Madrid' ? 'selected' : '' }}>Madrid</option>
                            <option value="Málaga" {{ old('province') == 'Málaga' ? 'selected' : '' }}>Málaga</option>
                            <option value="Melilla" {{ old('province') == 'Melilla' ? 'selected' : '' }}>Melilla</option>
                            <option value="Murcia" {{ old('province') == 'Murcia' ? 'selected' : '' }}>Murcia</option>
                            <option value="Navarra" {{ old('province') == 'Navarra' ? 'selected' : '' }}>Navarra</option>
                            <option value="Orense/Ourense" {{ old('province') == 'Orense/Ourense' ? 'selected' : '' }}>Orense/Ourense</option>
                            <option value="Palencia" {{ old('province') == 'Palencia' ? 'selected' : '' }}>Palencia</option>
                            <option value="Pontevedra" {{ old('province') == 'Pontevedra' ? 'selected' : '' }}>Pontevedra</option>
                            <option value="Salamanca" {{ old('province') == 'Salamanca' ? 'selected' : '' }}>Salamanca</option>
                            <option value="Segovia" {{ old('province') == 'Segovia' ? 'selected' : '' }}>Segovia</option>
                            <option value="Sevilla" {{ old('province') == 'Sevilla' ? 'selected' : '' }}>Sevilla</option>
                            <option value="Soria" {{ old('province') == 'Soria' ? 'selected' : '' }}>Soria</option>
                            <option value="Tarragona" {{ old('province') == 'Tarragona' ? 'selected' : '' }}>Tarragona</option>
                            <option value="Tenerife" {{ old('province') == 'Tenerife' ? 'selected' : '' }}>Tenerife</option>
                            <option value="Teruel" {{ old('province') == 'Teruel' ? 'selected' : '' }}>Teruel</option>
                            <option value="Toledo" {{ old('province') == 'Toledo' ? 'selected' : '' }}>Toledo</option>
                            <option value="Valencia" {{ old('province') == 'Valencia' ? 'selected' : '' }}>Valencia</option>
                            <option value="Valladolid" {{ old('province') == 'Valladolid' ? 'selected' : '' }}>Valladolid</option>
                            <option value="Vizcaya/Bizkaia" {{ old('province') == 'Vizcaya/Bizkaia' ? 'selected' : '' }}>Vizcaya/Bizkaia</option>
                            <option value="Zamora" {{ old('province') == 'Zamora' ? 'selected' : '' }}>Zamora</option>
                            <option value="Zaragoza" {{ old('province') == 'Zaragoza' ? 'selected' : '' }}>Zaragoza</option>
                        </select>
                        @error('province')
                            <div class="error">*{{ $message }}*</div>
                        @enderror
                    </div>
                    

                    <div class="form-group">
                        <label for="rol">Authority</label>
                        <select required name="authority" id="authority" class="form-control">
                            <option value="">Select Authority</option>
                            @if(Auth::user()->authority == 'root')
                            <option value="root" {{ old('authority') == 'root' ? 'selected' : '' }}>Root</option>
                            <option value="admin" {{ old('authority') == 'admin' ? 'selected' : '' }}>Admin</option>
                            <option value="user" {{ old('authority') == 'user' ? 'selected' : '' }}>User</option>  
                            @endif  
                            @if(Auth::user()->authority == 'admin')
                            <option value="admin" {{ old('authority') == 'admin' ? 'selected' : '' }}>Admin</option>
                            <option value="user" {{ old('authority') == 'user' ? 'selected' : '' }}>User</option>  
                            @endif                
                        </select>
                        @error('authority')
                            <div class="error">*{{ $message }}*</div>
                        @enderror
                    </div>
                    

                    <div class="form-group">
                        <label for="avatar">Avatar</label> <br>
                        <input type="file" id="avatar" name="avatar" value="{{ old('avatar') }}">
                        @error('avatar')
                            <div class="error">*{{ $message }}*</div>
                        @enderror
                    </div>
                    

                    <div class="form-group">
                        <label for="description">Description</label>
                        <textarea class="form-control" id="description" name="description" rows="3">{{ old('description') }}</textarea>
                        @error('description')
                            <div class="error">*{{ $message }}*</div>
                        @enderror
                    </div>
                    

                    <button type="submit" class="btn  btn-primary">Submit</button>
                
                </form>
            </div>
        </div>
    </div>    
</div>

@endsection