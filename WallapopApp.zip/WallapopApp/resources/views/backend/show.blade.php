@extends('layouts.admin')

@section('users')

<div class="main-body">

    <div class="row gutters-sm">
    <div class="col-md-4 mb-3">
        <div class="card">
        <div class="card-body">
            <div class="d-flex flex-column align-items-center text-center">
            <img src="data:image/jpeg;base64,{{ $user->avatar }}" alt="Admin" class="rounded-circle" width="150">
            <div class="mt-3">
                <h4>{{ $user->name }}</h4>
                <p class="text-secondary mb-1">{{ $user->authority }}</p>
                <p class="text-muted font-size-sm">{{ $user->province }}</p>
                @if(Auth::user()->authority === 'admin')
                    @if($user->authority === 'root')
                        <a href="{{ url('backend/' . $user->id . '/edit') }}" style="background-color:#ededed" class="btn btn-outline-primary">Edit</a>
                        <a href="#" id="deleteShow" style="background-color:#ededed" class="btn btn-outline-primary">Delete</a>
                    @else
                        <a href="{{ url('backend/' . $user->id . '/edit') }}" class="btn btn-outline-primary">Edit</a>
                        <a href="#" id="deleteShow" data-toggle="modal" data-target="#deleteModal" data-id="{{ $user->id }}" data-name="{{ $user->name }}" class="btn btn-outline-primary">Delete</a>
                    @endif
                @else
                    <a href="{{ url('backend/' . $user->id . '/edit') }}" class="btn btn-outline-primary">Edit</a>
                    <a href="#" id="deleteShow" data-toggle="modal" data-target="#deleteModal" data-id="{{ $user->id }}" data-name="{{ $user->name }}" class="btn btn-outline-primary">Delete</a>
                @endif  
            </div>
            </div>
        </div>
        </div>
    </div>
    <div class="col-md-8">
        <div class="card mb-3">
        <div class="card-body">
            <div class="row">
            <div class="col-sm-3">
                <h6 class="mb-0">Id</h6>
            </div>
            <div class="col-sm-9 text-secondary">
                {{ $user->id }}
            </div>
            </div>
            <hr>
            <div class="row">
            <div class="col-sm-3">
                <h6 class="mb-0">Name</h6>
            </div>
            <div class="col-sm-9 text-secondary">
                {{ $user->name }}
            </div>
            </div>
            <hr>
            <div class="row">
            <div class="col-sm-3">
                <h6 class="mb-0">Email</h6>
            </div>
            <div class="col-sm-9 text-secondary">
                {{ $user->email }}
            </div>
            </div>
            <hr>
            <div class="row">
            <div class="col-sm-3">
                <h6 class="mb-0">Birth Day</h6>
            </div>
            <div class="col-sm-9 text-secondary">
                {{ $user->birthDay }}
            </div>
            </div>
            <hr>
            <div class="row">
            <div class="col-sm-3">
                <h6 class="mb-0">Province</h6>
            </div>
            <div class="col-sm-9 text-secondary">
                {{ $user->province }}
            </div>
            </div>
            <hr>
            <div class="row">
            <div class="col-sm-3">
                <h6 class="mb-0">Authority</h6>
            </div>
            <div class="col-sm-9 text-secondary">
                {{ $user->authority }}
            </div>
            </div>
            <hr>
            <div class="row">
            <div class="col-sm-3">
                <h6 class="mb-0">Description</h6>
            </div>
            <div class="col-sm-9 text-secondary">
                {{ $user->description }}
            </div>
            </div>
        </div>
        </div>
        </div>
    </div>
    </div>
</div>

<form id="formDeleteShow" action="{{ url('backend/' . $user->id) }}" method="POST">
    @method('delete')
    @csrf
</form>

@endsection

@section('user-products')
<div class="main-body">
    <div class="row gutters-sm">
        <div class="col-md-12">
            <div class="card mb-3">
                <div class="card-body">
                    <h4>Products List of {{ $user->name }}</h4>
                    <div class="row">
                        
                        @foreach($products as $product)
                            <div class="card p-3 bg-white" style="margin:20px">
                                <div class="row">
                                    <a style="padding-left: 20px;" href="{{ url('backend/product/' . $product->id. '/edit') }}"><i style="font-size:1.2rem;" class="feather icon-edit"></i></a>
                                    <a href="javascript:void(0)" class="productDelete" data-id="{{ $product->id }}" data-name="{{ $product->name }}" data-id="{{ $user->id }}" data-name="{{ $user->name }}"><i style="padding: 3px; margin-left: 2px; font-size:1.2rem;" class="feather icon-trash-2"></i></a> 
                                </div>
                                
                                <div class="about-product text-center mt-2"><img src="data:image/jpeg;base64,{{ $product->avatar }}" width="300">
                                    <div>
                                        <h4>{{ $product->name }}</h4>
                                        <h6 class="mt-0 text-black-50">{{ $product->category->name }}</h6>
                                    </div>
                                </div>
                                <div class="stats mt-2">
                                    <div class="d-flex justify-content-between p-price"><span>Use:</span><span>{{ $product->use }}</span></div>
                                    <div class="d-flex justify-content-between p-price"><span>State:</span><span>{{ $product->state }}</span></div>
                                    <div class="d-flex justify-content-between p-price"><span>Date:</span><span>{{ $product->date }}</span></div>
                                </div>
                                <div class="d-flex justify-content-between total font-weight-bold mt-4"><span>Total</span><span>{{ $product->price }}€</span></div>
                            </div>    
                        @endforeach

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<form id="formProductDelete" action="" method="POST" data-url="{{ url('backend/product') }}">
    @method('delete')
    @csrf
</form>
@endsection

@section('modal')

<div id="deleteModal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="deleteModalLiveLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="deleteModalLiveLabel">Modal Title</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            </div>
            <div class="modal-body">
                <p id="refresh">Dou you want to delete from Users List?</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn  btn-secondary" data-dismiss="modal">Close</button>
                <button id="deleteTrue" type="button" class="btn  btn-primary">Delete</button>
            </div>
        </div>
    </div>
</div>

@endsection('modal')