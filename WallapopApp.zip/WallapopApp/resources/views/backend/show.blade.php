@extends('layouts.admin')

@section('users')

<div class="main-body">

    <div class="row gutters-sm">
    <div class="col-md-4 mb-3">
        <div class="card">
        <div class="card-body">
            <div class="d-flex flex-column align-items-center text-center">
            <img src="data:image/jpeg;base64,{{ $user->avatar }}" alt="Admin" class="rounded-circle" width="150">
            <div class="mt-3">
                <h4>{{ $user->name }}</h4>
                <p class="text-secondary mb-1">{{ $user->authority }}</p>
                <p class="text-muted font-size-sm">{{ $user->province }}</p>
                @if(Auth::user()->authority === 'admin')
                    @if($user->authority === 'root')
                        <a href="{{ url('backend/' . $user->id . '/edit') }}" style="background-color:#ededed" class="btn btn-outline-primary">Edit</a>
                        <a href="#" id="deleteShow" style="background-color:#ededed" class="btn btn-outline-primary">Delete</a>
                    @else
                        <a href="{{ url('backend/' . $user->id . '/edit') }}" class="btn btn-outline-primary">Edit</a>
                        <a href="#" id="deleteShow" data-toggle="modal" data-target="#deleteModal" data-id="{{ $user->id }}" data-name="{{ $user->name }}" class="btn btn-outline-primary">Delete</a>
                    @endif
                @else
                    <a href="{{ url('backend/' . $user->id . '/edit') }}" class="btn btn-outline-primary">Edit</a>
                    <a href="#" id="deleteShow" data-toggle="modal" data-target="#deleteModal" data-id="{{ $user->id }}" data-name="{{ $user->name }}" class="btn btn-outline-primary">Delete</a>
                @endif  
            </div>
            </div>
        </div>
        </div>
    </div>
    <div class="col-md-8">
        <div class="card mb-3">
        <div class="card-body">
            <div class="row">
            <div class="col-sm-3">
                <h6 class="mb-0">Id</h6>
            </div>
            <div class="col-sm-9 text-secondary">
                {{ $user->id }}
            </div>
            </div>
            <hr>
            <div class="row">
            <div class="col-sm-3">
                <h6 class="mb-0">Name</h6>
            </div>
            <div class="col-sm-9 text-secondary">
                {{ $user->name }}
            </div>
            </div>
            <hr>
            <div class="row">
            <div class="col-sm-3">
                <h6 class="mb-0">Email</h6>
            </div>
            <div class="col-sm-9 text-secondary">
                {{ $user->email }}
            </div>
            </div>
            <hr>
            <div class="row">
            <div class="col-sm-3">
                <h6 class="mb-0">Birth Day</h6>
            </div>
            <div class="col-sm-9 text-secondary">
                {{ $user->birthDay }}
            </div>
            </div>
            <hr>
            <div class="row">
            <div class="col-sm-3">
                <h6 class="mb-0">Province</h6>
            </div>
            <div class="col-sm-9 text-secondary">
                {{ $user->province }}
            </div>
            </div>
            <hr>
            <div class="row">
            <div class="col-sm-3">
                <h6 class="mb-0">Authority</h6>
            </div>
            <div class="col-sm-9 text-secondary">
                {{ $user->authority }}
            </div>
            </div>
            <hr>
            <div class="row">
            <div class="col-sm-3">
                <h6 class="mb-0">Description</h6>
            </div>
            <div class="col-sm-9 text-secondary">
                {{ $user->description }}
            </div>
            </div>
        </div>
        </div>
        </div>
    </div>
    </div>
</div>

<form id="formDeleteShow" action="{{ url('backend/' . $user->id) }}" method="POST">
    @method('delete')
    @csrf
</form>

@endsection

@section('modal')

<div id="deleteModal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="deleteModalLiveLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="deleteModalLiveLabel">Modal Title</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            </div>
            <div class="modal-body">
                <p id="refresh">Dou you want to delete from Users List?</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn  btn-secondary" data-dismiss="modal">Close</button>
                <button id="deleteTrue" type="button" class="btn  btn-primary">Delete</button>
            </div>
        </div>
    </div>
</div>

@endsection('modal')