<!DOCTYPE html>
<html lang="en">

<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
    <title>Gradient Able Free Bootstrap Admin Template by CodedThemes</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="description" content="" />
    <meta name="keywords" content="">
    <meta name="author" content="Codedthemes" />
    <!-- Favicon icon -->
    <link rel="icon" href="{{ url('assetsBackend/images/favicon.ico') }}" type="image/x-icon">

    <!-- vendor css -->
	<link rel="stylesheet" href="{{ url('assetsBackend/css/style.css') }}">
	<link rel="stylesheet" href="{{ url('assets/style.css') }}">
	<link rel="stylesheet" href="{{ url('assetsBackend/css/style2.css') }}">
    
    

</head>
<body class="">
	<!-- [ Pre-loader ] start -->
	<div class="loader-bg">
		<div class="loader-track">
			<div class="loader-fill"></div>
		</div>
	</div>
	<!-- [ Pre-loader ] End -->
	<!-- [ navigation menu ] start -->
	<nav class="pcoded-navbar menupos-fixed menu-light ">
		<div class="navbar-wrapper  ">
			<div class="navbar-content scroll-div " >
				<ul class="nav pcoded-inner-navbar ">
					<li class="nav-item pcoded-menu-caption">
						<label>Navigation</label>
					</li>
					<li class="nav-item">
					    <a href="{{ url('home') }}" class="nav-link "><span class="pcoded-micon"><i class="feather icon-home"></i></span><span class="pcoded-mtext">Wallapop Frontend</span></a>
					</li>
					<li class="nav-item pcoded-hasmenu">
					    <a href="#!" class="nav-link "><span class="pcoded-micon"><i class="feather icon-layout"></i></span><span class="pcoded-mtext">Users Admin</span></a>
					    <ul class="pcoded-submenu">
					        <li><a href="{{ url('backend') }}">List Users</a></li>
					        <li><a href="{{ url('backend/create') }}">Create User</a></li>
					    </ul>
					</li>				
			</div>
		</div>
	</nav>
	<!-- [ navigation menu ] end -->
	<!-- [ Header ] start -->
	<header class="navbar pcoded-header navbar-expand-lg navbar-light headerpos-fixed header-blue">	
		<div class="m-header">
			<a class="mobile-menu" id="mobile-collapse" href="#!"><span></span></a>
			<a href="#!" class="b-brand">
				<!-- ========   change your logo hear   ============ -->
				<img src="{{ url('assetsBackend/images/logo.png') }}" alt="" class="logo">
				<img src="{{ url('assetsBackend/images/logo-icon.png') }}" alt="" class="logo-thumb">
			</a>
			<a href="#!" class="mob-toggler">
				<i class="feather icon-more-vertical"></i>
			</a>
		</div>
		<div class="collapse navbar-collapse">
			<ul class="navbar-nav mr-auto">
				<li class="nav-item">
					<form action="{{ route('backend.index') }}">
						<a href="#!" class="pop-search"><i class="feather icon-search"></i></a>
						<div class="search-bar">
							<input name="search" value="{{$search ?? ''}}" class="form-control border-0 shadow-none" type="search" placeholder="Search here..." aria-label="Search">
							<button type="submit" class="close" aria-label="Close">
								<span aria-hidden="true">&times;</span>
							</button>
						</div>
					</form>
				</li>
				<li class="nav-item">
					<a href="#!" class="full-screen" onclick="javascript:toggleFullScreen()"><i class="feather icon-maximize"></i></a>
				</li>
			</ul>
			<ul class="navbar-nav ml-auto">
				<li>
					<div class="dropdown drp-user">
						<a href="#!" class="dropdown-toggle" data-toggle="dropdown">
							<img src="data:image/jpeg;base64,{{ Auth::user()->avatar }}" class="img-radius wid-40" alt="User-Profile-Image">
						</a>
						<div class="dropdown-menu dropdown-menu-right profile-notification">
							<div class="pro-head">
								<img src="data:image/jpeg;base64,{{ Auth::user()->avatar }}" class="img-radius" alt="User-Profile-Image">
								<span >{{ Auth::user()->name }}</span>
								<hr>
								<span>{{ Auth::user()->authority }}</span>
						
								
									
								
								
							</div>
							<ul class="pro-body">
								<li><a href="{{ url('backend/' . Auth::user()->id) }}" class="dropdown-item"><i class="feather icon-user"></i> Profile</a></li>
								<li><a href="{{ route('logout') }}" onclick="event.preventDefault(); document.getElementById('logout-form').submit();" class="dropdown-item"><i class="feather icon-log-out"></i></i>Logout</a></li>
							</ul>
						</div>
					</div>
				</li>
			</ul>
		</div>
	</header>
	<!-- [ Header ] end -->

	<form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">
		@csrf
	</form>

<!-- [ Main Content ] start -->
<div class="pcoded-main-container">
    <div class="pcoded-content">
		<div class="col-md-12">
			<div class="page-header">
				<div class="page-block">
					<div class="row align-items-center">
						<div class="col-md-12">
							<div class="page-header-title">
								<h5 class="m-b-10">Navegation Bar</h5>
							</div>
							<ul class="breadcrumb">
								<li class="breadcrumb-item"><a href="{{ url('backend') }}">User List <i class="feather icon-home"></i></a></li>
								<li class="breadcrumb-item"><a href="{{ url('backend/create') }}">User Create <i class="feather icon-user-plus"></i></a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		
			@yield('users')
			@yield('user-products')
			@yield('modal')
		
		</div>
    </div>
</div>


    <!-- Required Js -->
    <script src="{{ url('assetsBackend/js/vendor-all.min.js') }}"></script>
    <script src="{{ url('assetsBackend/js/plugins/bootstrap.min.js') }}"></script>
    <script src="{{ url('assetsBackend/js/pcoded.min.js') }}"></script>

<!-- Apex Chart -->
<script src="{{ url('assetsBackend/js/plugins/apexcharts.min.js') }}"></script>


<!-- custom-chart js -->
<script src="{{ url('assetsBackend/js/pages/dashboard-main.js') }}"></script>
<script src="{{ url('assetsBackend/js/delete.js') }}"></script>

</body>


<!-- Mirrored from lite.codedthemes.com/gradient-able/bootstrap/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 30 Jan 2021 23:41:53 GMT -->
</html>
