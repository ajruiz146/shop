<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css" type="text/css" rel="stylesheet">
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    
    <link rel="stylesheet" href="{{ url('assets/fonts/stylesheet.e9dc714d.css') }}">
    <!-- Swiper-->
    <link rel="stylesheet" href="{{ url('assets/vendor/swiper/css/swiper.min.css') }}">
    <!-- AOS - AnimationOnScroll-->
    <link rel="stylesheet" href="{{ url('assets/vendor/aos/aos.css') }}">
    <!-- Custom Scrollbar-->
    <link rel="stylesheet" href="{{ url('assets/vendor/malihu-custom-scrollbar-plugin/jquery.mCustomScrollbar.css') }}">
    <!-- Theme stylesheet-->
    <link rel="stylesheet" href="{{ url('assets/css/style.default.d1b89a2d.css') }}" id="theme-stylesheet">
    <!-- Custom stylesheet - for your changes-->
    <link rel="stylesheet" href="{{ url('assets/css/custom.0a822280.css') }}">
    <!-- Favicon-->
    <link rel="shortcut icon" href="{{ url('assets/img/favicon.png') }}">
    <!-- FontAwesome-->
    <link rel="stylesheet" href="{{ url('assets/css/all.css') }}">
    <link rel="stylesheet" href="{{ url('assets/css/style.css') }}">
    <link rel="stylesheet" href="{{ url('assets/css/styleChat.css') }}">

    <link rel="stylesheet" href="{{ url('assets/css/styleChat.css') }}">

</head>
<body>





    <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="{{ url('assets/js/scroll.js') }}"></script>
    </body>
    </html>