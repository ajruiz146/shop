@extends('layouts.frontend')


@section('username')
{{ auth()->user()->name }}
@endsection

@section('profile')

<div class="col-xl-3 col-lg-4 mb-5">
    <div class="customer-sidebar card border-0">
        <div class="customer-profile"><a class="d-inline-block" href="#"><img
                    class="img-fluid rounded-circle customer-image"
                    src="data:image/jpeg;base64,{{ auth()->user()->avatar }}" alt=""></a>
            <h5>{{ auth()->user()->name }}</h5>
            <p class="text-muted text-sm mb-0">{{ auth()->user()->province }}</p>
        </div>
        <nav class="list-group customer-nav"><a id="upload"
                class="active list-group-item d-flex justify-content-between align-items-center"
                href="javascript:void(0)"><span>
                    <svg class="svg-icon svg-icon-heavy mr-2">
                        <use xlink:href="#paper-bag-1"> </use>
                    </svg>Upload Products</span>
                <div class="badge badge-pill badge-light font-weight-normal px-3">{{ $products->count() }}</div>
            </a>
            <a id="profile" class="list-group-item d-flex justify-content-between align-items-center"
                href="javascript:void(0)">
                <span>
                    <svg class="svg-icon svg-icon-heavy mr-2">
                        <use xlink:href="#male-user-1"> </use>
                    </svg>Profile</span></a><a id="wishlist"
                class="list-group-item d-flex justify-content-between align-items-center"
                href="javascript:void(0)"><span>
                    <svg class="svg-icon svg-icon-heavy mr-2">
                        <use xlink:href="#real-estate-1"> </use>
                    </svg>Wishlist</span>
                <div class="badge badge-pill badge-light font-weight-normal px-3">{{ $wishlists->count() }}</div>
            </a><a id="chats" class="list-group-item d-flex justify-content-between align-items-center"
                href="javascript:void(0)"><span>
                    <svg class="svg-icon svg-icon-heavy mr-2">
                        <use xlink:href="#heart-1"> </use>
                    </svg>Chats</span></a><a class="list-group-item d-flex justify-content-between align-items-center"
                href="{{ route('logout') }}"
                onclick="event.preventDefault(); document.getElementById('logout-form').submit();"><span>
                    <svg class="svg-icon svg-icon-heavy mr-2">
                        <use xlink:href="#exit-1"> </use>
                    </svg>Log out</span></a>
        </nav>
    </div>
</div>

<form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">
    @csrf
</form>

@endsection

@section('createproduct')

<a href="#" id="add-product">Añadir producto</a>
<!-- Desde aqui -->
<div id="create-product">
    <form action="{{ url('product') }}" method="POST" enctype='multipart/form-data'>
        @csrf

        <div class="form-group">
            <input type="hidden" class="form-control" id="iduser" name="iduser" value="{{ auth()->user()->id }}">
        </div>

        <div class="form-group">
            <label for="name">Product Name</label>
            <input type="text" class="form-control" id="name" name="name" placeholder="Enter name"
                value="{{ old('name') }}">
            @error('name')
            <div class="error">*{{ $message }}*</div>
            @enderror
        </div>

        <div class="form-group">
            <label for="rol">Category</label>
            <select required name="idcategory" id="idcategory" class="form-control">
                <option value="">Select Category</option>
                @foreach($categories as $category)
                <option value="{{ $category->id }}" {{ old('idcategory')==$category->id ? 'selected' : '' }}>{{
                    $category->name }}</option>
                @endforeach
            </select>
            @error('authority')
            <div class="error">*{{ $message }}*</div>
            @enderror
        </div>

        <div class="form-group">
            <label for="text">Use</label>
            <input type="text" class="form-control" id="use" name="use" placeholder="Enter use"
                value="{{ old('use') }}">
            @error('use')
            <div class="error">*{{ $message }}*</div>
            @enderror
        </div>


        <div class="form-group">
            <label for="state">State</label>
            <input type="text" class="form-control" id="state" name="state" placeholder="State"
                value="{{ old('state') }}">
            @error('state')
            <div class="error">*{{ $message }}*</div>
            @enderror
        </div>


        <div class="form-group">
            <label for="price">Price</label>
            <input type="text" class="form-control" id="price" name="price" placeholder="€" value="{{ old('price') }}">
            @error('price')
            <div class="error">*{{ $message }}*</div>
            @enderror
        </div>

        <div class="form-group">
            <label for="description">Description</label>
            <textarea class="form-control" id="description" name="description"
                rows="4">{{ old('description') }}</textarea>
            @error('description')
            <div class="error">*{{ $message }}*</div>
            @enderror
        </div>

        <div class="form-group">
            <label for="image">Images</label> <br>
            <input type="file" id="image" name="image[]" multiple>
            @error('image')
            <div class="error">*{{ $message }}*</div>
            @enderror
        </div>


        <button type="submit" class="btn  btn-primary">Submit</button>

    </form>
</div>
@endsection
@section('information')

<div id="uploadProducts" class="col-lg-10 col-xl-9">

    <div class="cart">
        <div class="cart-wrapper">
            <div class="cart-body">
                <!-- Product-->
                <table class="table">
                    <thead class="thead-dark">
                        <tr>
                            <th scope="col"></th>
                            <th scope="col">Name</th>
                            <th scope="col">Category</th>
                            <th scope="col">Use</th>
                            <th scope="col">State</th>
                            <th scope="col">Prize</th>
                            <th scope="col">Show</th>
                            <th scope="col">Edit</th>
                            <th scope="col">Delete</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($products as $index => $product)
                        <tr>
                            <td scope="row"><img class="cart-item-img"
                                    src="data:image/jpeg;base64,{{ $product->avatar }}" alt="..."></td>
                            <td>{{ $product->name }}</td>
                            <td>{{ $product->category->name }}</td>
                            <td>{{ $product->use }}</td>
                            <td>{{ $product->state }}</td>
                            <td>{{ $product->price }}€</td>
                            <td><a href="{{ url('product/' . $product->id)}}">Show</a></td>
                            <td><a href="#" class="edit-product">Edit</a></td>
                            <td><a href="#" data-toggle="modal" data-target="#deleteModal" data-id="{{ $product->id }}"
                                    data-name="{{ $product->name }}" class="deleteIndex">Delete</a></td>
                        </tr>
                        <tr>
                            <td id="{{ 'create-product-' . $index }}">
                                <div>
                                    <form action="{{ url('product/' . $product->id) }}" method="POST"
                                        enctype='multipart/form-data'>
                                        @csrf
                                        @method('put')
                                        <div class="form-group">
                                            <input type="hidden" class="form-control" id="iduser" name="iduser"
                                                value="{{ auth()->user()->id }}">
                                        </div>

                                        <div class="form-group">
                                            <label for="name">Product Name</label>
                                            <input type="text" class="form-control" id="name" name="name"
                                                placeholder="Enter name" value="{{ old('name', $product->name) }}">
                                            @error('name')
                                            <div class="error">*{{ $message }}*</div>
                                            @enderror
                                        </div>

                                        <div class="form-group">
                                            <label for="rol">Category</label>
                                            <select required name="idcategory" id="idcategory" class="form-control">
                                                @foreach($categories as $category)
                                                <option value="{{ $category->id }}" {{ $product->idcategory ==
                                                    $category->id ? 'selected' : '' }} {{ old('idcategory') ==
                                                    $category->id ? 'selected' : '' }}>{{ $category->name }}</option>
                                                @endforeach
                                            </select>
                                            @error('authority')
                                            <div class="error">*{{ $message }}*</div>
                                            @enderror
                                        </div>

                                        <div class="form-group">
                                            <label for="text">Use</label>
                                            <input type="text" class="form-control" id="use" name="use"
                                                placeholder="Enter use" value="{{ old('use', $product->use) }}">
                                            @error('use')
                                            <div class="error">*{{ $message }}*</div>
                                            @enderror
                                        </div>


                                        <div class="form-group">
                                            <label for="state">State</label>
                                            <input type="text" class="form-control" id="state" name="state"
                                                placeholder="State" value="{{ old('state', $product->state) }}">
                                            @error('state')
                                            <div class="error">*{{ $message }}*</div>
                                            @enderror
                                        </div>


                                        <div class="form-group">
                                            <label for="price">Price</label>
                                            <input type="text" class="form-control" id="price" name="price"
                                                placeholder="€" value="{{ old('price', $product->price) }}">
                                            @error('price')
                                            <div class="error">*{{ $message }}*</div>
                                            @enderror
                                        </div>

                                        <div class="form-group">
                                            <label for="description">Description</label>
                                            <textarea class="form-control" id="description" name="description"
                                                rows="4">{{ old('description', $product->description) }}</textarea>
                                            @error('description')
                                            <div class="error">*{{ $message }}*</div>
                                            @enderror
                                        </div>

                                        <div class="form-group">
                                            <label for="image">Images</label> <br>
                                            <input type="file" id="image" name="image[]" multiple>
                                            @error('image')
                                            <div class="error">*{{ $message }}*</div>
                                            @enderror
                                        </div>
                                        <button type="submit" class="btn  btn-primary">Submit</button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
                <!-- /Desde aqui -->
                <!-- /Product -->
            </div>
        </div>
    </div>
</div>

<form id="formDeleteIndex" action="" method="POST" data-url="{{ url('product') }}">
    @method('delete')
    @csrf
</form>
@endsection

@section('profile-content')



<div id="profilecontent" class="col-lg-10 col-xl-9">
    <div class="cart">
        <div class="cart-wrapper">
            <div class="cart-body">
                <form action="{{ url('profile/' . $user->id) }}" method="POST" enctype='multipart/form-data'>
                    @csrf
                    @method('put')
                    <div class="form-group">
                        <label for="name">Name</label>
                        <input type="text" class="form-control" id="name" name="name" placeholder="Enter name"
                            value="{{ old('name', $user->name) }}">
                        @error('name')
                        <div class="error">*{{ $message }}*</div>
                        @enderror
                    </div>

                    <div class="form-group">
                        <label for="name">Email</label>
                        <input type="email" class="form-control" id="email" name="email" placeholder="Enter email"
                            value="{{ old('email', $user->email) }}">
                        @error('email')
                        <div class="error">*{{ $message }}*</div>
                        @enderror
                    </div>

                    <div class="form-group">
                        <label for="password">Password</label>
                        <input type="password" class="form-control" id="password" name="password"
                            placeholder="Password">
                        @error('password')
                        <div class="error">*{{ $message }}*</div>
                        @enderror
                    </div>

                    <div class="form-group">
                        <label for="birthDay">Birth Day</label>
                        <input type="date" class="form-control" id="birthDay" name="birthDay"
                            value="{{ old('birthDay', $user->birthDay) }}">
                        @error('birthDay')
                        <div class="error">*{{ $message }}*</div>
                        @enderror
                    </div>

                    <div class="form-group">
                        <label for="province">Province</label>
                        <select required name="province" class="form-control">
                            <option value="{{ $user->province }}" selected>{{ $user->province }}</option>
                            <option value="Álava/Araba">Álava/Araba</option>
                            <option value="Albacete">Albacete</option>
                            <option value="Alicante">Alicante</option>
                            <option value="Almería">Almería</option>
                            <option value="Asturias">Asturias</option>
                            <option value="Ávila">Ávila</option>
                            <option value="Badajoz">Badajoz</option>
                            <option value="Baleares">Baleares</option>
                            <option value="Barcelona">Barcelona</option>
                            <option value="Burgos">Burgos</option>
                            <option value="Cáceres">Cáceres</option>
                            <option value="Cádiz">Cádiz</option>
                            <option value="Cantabria">Cantabria</option>
                            <option value="Castellón">Castellón</option>
                            <option value="Ceuta">Ceuta</option>
                            <option value="Ciudad Real">Ciudad Real</option>
                            <option value="Córdoba">Córdoba</option>
                            <option value="Cuenca">Cuenca</option>
                            <option value="Gerona/Girona">Gerona/Girona</option>
                            <option value="Granada">Granada</option>
                            <option value="Guadalajara">Guadalajara</option>
                            <option value="Guipúzcoa/Gipuzkoa">Guipúzcoa/Gipuzkoa</option>
                            <option value="Huelva">Huelva</option>
                            <option value="Huesca">Huesca</option>
                            <option value="Jaén">Jaén</option>
                            <option value="La Coruña/A Coruña">La Coruña/A Coruña</option>
                            <option value="La Rioja">La Rioja</option>
                            <option value="Las Palmas">Las Palmas</option>
                            <option value="León">León</option>
                            <option value="Lérida/Lleida">Lérida/Lleida</option>
                            <option value="Lugo">Lugo</option>
                            <option value="Madrid">Madrid</option>
                            <option value="Málaga">Málaga</option>
                            <option value="Melilla">Melilla</option>
                            <option value="Murcia">Murcia</option>
                            <option value="Navarra">Navarra</option>
                            <option value="Orense/Ourense">Orense/Ourense</option>
                            <option value="Palencia">Palencia</option>
                            <option value="Pontevedra">Pontevedra</option>
                            <option value="Salamanca">Salamanca</option>
                            <option value="Segovia">Segovia</option>
                            <option value="Sevilla">Sevilla</option>
                            <option value="Soria">Soria</option>
                            <option value="Tarragona">Tarragona</option>
                            <option value="Tenerife">Tenerife</option>
                            <option value="Teruel">Teruel</option>
                            <option value="Toledo">Toledo</option>
                            <option value="Valencia">Valencia</option>
                            <option value="Valladolid">Valladolid</option>
                            <option value="Vizcaya/Bizkaia">Vizcaya/Bizkaia</option>
                            <option value="Zamora">Zamora</option>
                            <option value="Zaragoza">Zaragoza</option>
                        </select>
                        @error('province')
                        <div class="error">*{{ $message }}*</div>
                        @enderror
                    </div>

                    <div class="form-group">
                        <label for="avatar">Avatar</label> <br>
                        <input type="file" id="avatar" name="avatar">
                        @error('avatar')
                        <div class="error">*{{ $message }}*</div>
                        @enderror
                    </div>

                    <div class="form-group">
                        <label for="description">Description</label>
                        <textarea class="form-control" id="description" name="description"
                            rows="3">{{ old('description', $user->description) }}</textarea>
                        @error('description')
                        <div class="error">*{{ $message }}*</div>
                        @enderror
                    </div>

                    <button type="submit" class="btn  btn-primary">Submit</button>
                    <a href="{{ url('profile/' . $user->id . '/edit') }}" id="deleteShow" data-toggle="modal"
                        data-target="#deleteModal" data-id="{{ $user->id }}" data-name="{{ $user->name }}"
                        class="offset-md-9 btn btn-outline-primary">Drop Out</a>
                </form>
            </div>
        </div>
    </div>
</div>

<form id="formDeleteShow" action="{{ url('profile/' . $user->id) }}" method="POST">
    @method('delete')
    @csrf
</form>
@endsection

@section('prueba')

<div id="wishcontent" class="col-lg-10 col-xl-9">
    <div class="cart">
        <div class="cart-wrapper">
            <div class="cart-body">
                <!-- Grid row -->
                <div class="row">
                    <!-- Grid column -->
                    @foreach($wishlists as $wishlist)
                    <div class="col-md-3 mb-3" style="padding: 30px; margin: 0 30px;">
                        <!-- Card -->
                        <div class="">
                            <div class="view zoom overlay z-depth-2 rounded">
                                <img class="img-fluid w-100" src="data:image/jpeg;base64,{{ $product->avatar }}"
                                    alt="Sample">
                            </div>
                            <div class="text-center pt-4">
                                <h5>{{ $wishlist->product->name }}</h5>
                                <p class="mb-2 text-muted text-uppercase small">{{ $wishlist->product->state }}</p>
                                <hr>
                                <h6 class="mb-3">{{ $wishlist->product->price }}€</h6>
                                <button type="button" class="btn btn-primary btn-sm mr-1 mb-2"><i
                                        class="fas fa-shopping-cart pr-2"></i>Contact</button>
                                <button type="button" class="btn btn-light btn-sm mr-1 mb-2"><i
                                        class="fas fa-info-circle pr-2"></i>Details</button>
                                <a href="#" data-toggle="modal" data-target="#deleteModal" data-id="{{ $wishlist->id }}"
                                    data-name="{{ $wishlist->name }}"
                                    class="deleteWish btn btn-elegant btn-sm px-3 mb-2 material-tooltip-main">Delete</a>
                            </div>
                        </div>
                        <!-- Card -->
                    </div>
                    @endforeach
                </div>
                <!-- Grid row -->
            </div>
        </div>
    </div>
</div>


<form id="formDeleteWish" action="" method="POST" data-url="{{ url('wishlist') }}">
    @method('delete')
    @csrf
</form>
@endsection

@section('chats-content')
<div id="chatscontent" class="col-lg-10 col-xl-9">
    <div class="cart">
        <div class="cart-wrapper">
            <div class="cart-body">
                <h4>Chats</h4>
                <div class="inbox_chat">
                    @foreach($chats as $chat)
                    <a href="{{ url('chat/' . $chat->id) }}">
                        <div class="chat_list active_chat">
                            <div class="chat_people">
                                <div class="chat_img"> <img src="https://s03.s3c.es/imag/_v0/770x420/e/c/9/490x_wallapop-logo.jpg" alt="sunil"> </div>
                                <div class="chat_ib">
                                
                                @if($chat->idemisor == auth()->user()->id)
                                    <h5>Usuario: {{ $chat->idreceptor }}<span class="chat_date">{{ $chat->id }}</span></h5>
                                @else
                                    <h5>Usuario: {{ $chat->idemisor }}<span class="chat_date">{{ $chat->id }}</span></h5>
                                @endif
                                
                                <p>{{ $chat->product->name }}</p>
                                </div>
                            </div>
                        </div>
                    </a>
                    @endforeach
                </div>
            </div>
        </div>
    </div>
</div>


@endsection

@section('modal')

<div id="deleteModal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="deleteModalLiveLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="deleteModalLiveLabel">Modal Title</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                        aria-hidden="true">&times;</span></button>
            </div>
            <div class="modal-body">
                <p id="refresh">Hey, are you sure?</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn  btn-secondary" data-dismiss="modal">Close</button>
                <button id="deleteConfirm" type="button" class="btn  btn-primary">Delete</button>
            </div>
        </div>
    </div>
</div>

@endsection



@section('wishlist-content')

<div id="wishcontent" class="col-lg-10 col-xl-9">
    <div class="cart">
        <div class="cart-wrapper">
            <div class="cart-body">
                <table class="table">
                    <thead class="thead-dark">
                        <tr>
                            <th scope="col"></th>
                            <th scope="col">Name</th>
                            <th scope="col">State</th>
                            <th scope="col">Prize</th>
                            <th scope="col">Owner</th>
                            <th scope="col">Show</th>
                            <th scope="col">Delete</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($wishlists as $wishlist)
                        <tr>
                            <td scope="row"><img class="cart-item-img"
                                    src="data:image/jpeg;base64,{{ $product->avatar }}" alt="..."></td>
                            <td>{{ $wishlist->product->name }}</td>
                            <td>{{ $wishlist->product->state }}</td>
                            <td>{{ $wishlist->product->price }}€</td>
                            <td><img class="cart-item-img" style="border-radius:50%; height:75px;"
                                    src="data:image/jpeg;base64,{{ $wishlist->product->user->avatar }}" alt="..."> {{
                                $wishlist->product->user->name }}</td>
                            <td><a href="{{ url('wishlist/' . $wishlist->id)}}">Show</a></td>
                            <td><a href="#" data-toggle="modal" data-target="#deleteModal" data-id="{{ $wishlist->id }}"
                                    data-name="{{ $wishlist->name }}" class="deleteWish">Delete</a></td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<form id="formDeleteWish" action="" method="POST" data-url="{{ url('wishlist') }}">
    @method('delete')
    @csrf
</form>

@endsection


