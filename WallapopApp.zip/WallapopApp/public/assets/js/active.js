$('#form_sort').change(function() {
    var selected_option = $('#form_sort option:selected');
    let href;

    if(selected_option.val() == 'priceasc') {
        href = $('#priceasc').attr('href');
    }
    
    if(selected_option.val() == 'pricedesc') {
        href = $('#pricedesc').attr('href');
    }
    
    if(selected_option.val() == 'nameasc') {
        href = $('#nameasc').attr('href');
    }
    
    if(selected_option.val() == 'namedesc') {
        href = $('#namedesc').attr('href');
    }
    window.location.href = href;
});
