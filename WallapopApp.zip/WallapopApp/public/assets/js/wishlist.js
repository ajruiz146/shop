$('#wishlist-add').click(function() {
    $('#wishlist-save').submit();
});