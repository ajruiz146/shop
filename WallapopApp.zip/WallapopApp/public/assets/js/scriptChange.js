$("#wishcontent").hide();
$("#profilecontent").hide();
$("#chatscontent").hide();

$("#profile").click(function() {
    $("#profile").attr('class', 'active list-group-item d-flex justify-content-between align-items-center');

    $("#wishlist").attr('class', 'list-group-item d-flex justify-content-between align-items-center');
    $("#upload").attr('class', 'list-group-item d-flex justify-content-between align-items-center');
    $("#chats").attr('class', 'list-group-item d-flex justify-content-between align-items-center');


    $("#profilecontent").fadeIn(700);

    $("#uploadProducts").fadeOut(300);
    $("#chatscontent").fadeOut(300);
    $("#wishcontent").fadeOut(300);
    
    $("#add-product").fadeOut(300);

    $("#subtitle-index").html("Profile");
});

$("#upload").click(function() {
    $("#upload").attr('class', 'active list-group-item d-flex justify-content-between align-items-center');
    
    $("#wishlist").attr('class', 'list-group-item d-flex justify-content-between align-items-center');
    $("#chats").attr('class', 'list-group-item d-flex justify-content-between align-items-center');
    $("#profile").attr('class', 'list-group-item d-flex justify-content-between align-items-center');


    $("#uploadProducts").fadeIn(700);

    $("#wishcontent").fadeOut(300);
    $("#profilecontent").fadeOut(300);
    $("#chatscontent").fadeOut(300);

    $("#add-product").fadeIn(700);  

    $("#subtitle-index").html("My Products");
});

$("#wishlist").click(function() {
    $("#wishlist").attr('class', 'active list-group-item d-flex justify-content-between align-items-center');
    
    $("#chats").attr('class', 'list-group-item d-flex justify-content-between align-items-center');
    $("#upload").attr('class', 'list-group-item d-flex justify-content-between align-items-center');
    $("#profile").attr('class', 'list-group-item d-flex justify-content-between align-items-center');


    $("#wishcontent").fadeIn(700);

    $("#uploadProducts").fadeOut(300);
    $("#profilecontent").fadeOut(300);
    $("#chatscontent").fadeOut(300);

    $("#add-product").fadeOut(300);  

    $("#subtitle-index").html("WishList");
});

$("#chats").click(function() {
    $("#chats").attr('class', 'active list-group-item d-flex justify-content-between align-items-center');
    
    $("#wishlist").attr('class', 'list-group-item d-flex justify-content-between align-items-center');
    $("#upload").attr('class', 'list-group-item d-flex justify-content-between align-items-center');
    $("#profile").attr('class', 'list-group-item d-flex justify-content-between align-items-center');

    $("#chatscontent").fadeIn(700);

    $("#wishcontent").fadeOut(300);
    $("#uploadProducts").fadeOut(300);
    $("#profilecontent").fadeOut(300);

    $("#add-product").fadeOut(300);  

    $("#subtitle-index").html("Chats");
    
});

