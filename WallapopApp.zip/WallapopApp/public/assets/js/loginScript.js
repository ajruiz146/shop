
if ($("#informative").length) {
    $("#informative").modal('show');
    $("#refreshInfo").html('Your account was deleted correctly!');
}

if($('#login').length) {
    $("#informative2").modal('show');
    $("#refreshInfo").html('Debe verificar su email para acceder');
}

if($('#register').length) {
    $("#informative2").modal('show');
    $("#refreshInfo").html('Registrado correctamente, verifique su email para acceder');
}
