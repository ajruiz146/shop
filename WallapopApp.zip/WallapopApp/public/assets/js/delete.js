let deleteIndex = document.getElementsByClassName("deleteIndex");
let formDeleteIndex = document.getElementById("formDeleteIndex");
let deleteConfirm = document.getElementById("deleteConfirm");

let deleteWish = document.getElementsByClassName("deleteWish");
let formDeleteWish = document.getElementById("formDeleteWish");

for (let i = 0; i < deleteIndex.length; i++) {
    deleteIndex[i].addEventListener('click', function () {
        let id = deleteIndex[i].dataset.id;
        let name = deleteIndex[i].dataset.name;
        modalRefresh(id, name);
        deleteConfirm.addEventListener('click', function () {
            let url = formDeleteIndex.dataset.url;
            formDeleteIndex.action = url + '/' + id;
            formDeleteIndex.submit();
        });
    });


    deleteWish[i].addEventListener('click', function () {
        let id = deleteWish[i].dataset.id;
        let name = deleteWish[i].dataset.name;
        modalRefresh(id, name);
        deleteConfirm.addEventListener('click', function () {
            let url = formDeleteWish.dataset.url;
            formDeleteWish.action = url + '/' + id;
            formDeleteWish.submit();
        });
    });
}

function modalRefresh(id, name) {
    let refresh = document.getElementById("refresh");
    refresh.innerHTML = 'Sure to delete product ' + name + '?';
    $('#deleteConfirm').show();
}

let formDeleteShow = document.getElementById("formDeleteShow");
let deleteTrue = document.getElementById("deleteTrue");
let deleteShow = document.getElementById("deleteShow");

if(deleteShow) {
    deleteShow.addEventListener('click', function () {
        let id = this.dataset.id;
        let name = this.dataset.name;
        let refresh = document.getElementById("refresh");
        refresh.innerHTML = 'Sure to delete product ' + name + '?';
        deleteTrue.addEventListener('click', function () {
            formDeleteShow.submit();
        });
    });
}

let formDeleteImage = document.getElementById('formDeleteImage');
let imagenesBorrar = document.getElementsByClassName('borradoImagen');

if(formDeleteImage) {
    for (let i = 0; i < imagenesBorrar.length; i++) {
        imagenesBorrar[i].addEventListener('click', function () {
            let resultado = confirm("¿Deseas borrar la imagen?");
            if(resultado) {
                let url = formDeleteImage.dataset.url;
                let id = imagenesBorrar[i].dataset.id;
                formDeleteImage.action = url + '/' + id;
                formDeleteImage.submit();
            }
        }
        )
    };
}