
$('header').hide();
$('.hero-heading').hide();

var elem = document.getElementById('msg_history');
elem.scrollTop = elem.scrollHeight;
