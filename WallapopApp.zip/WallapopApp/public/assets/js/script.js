$("#create-product").hide();
let addProduct =  document.getElementById("add-product");
if(addProduct) {
    addProduct.addEventListener('click', function(event) {
        event.preventDefault();
        if ($("#create-product").is(":visible")){ 
            $("#create-product").fadeOut(500);
            $('#add-product').hide().html('Añadir producto').fadeIn(400);
        } else {
            $("#create-product").fadeIn(500);
            $('#add-product').hide().html('Dejar de añadir').fadeIn(400);
        }
    });
}

let editProduct =  document.getElementsByClassName("edit-product");

if(editProduct[0]) {
    for(let i = 0; i < editProduct.length; i++) {
        editProduct[i].addEventListener('click', function(event) {
            event.preventDefault();
            if ($("#create-product-" + i).is(":visible")){ 
                $("#create-product-" + i).fadeOut(500);
                $('#add-product').hide().html('Añadir producto').fadeIn(400);
            } else {
                $("#create-product-" + i).fadeIn(500);
                $('#add-product').hide().html('Dejar de añadir').fadeIn(400);
            }
        });
    }
    
}
for(let i = 0; i < editProduct.length; i++) {
    $("#create-product-" + i).hide();
}

