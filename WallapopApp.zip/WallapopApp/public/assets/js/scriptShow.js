$("#edit-product-div").hide();

$("#edit-product").click(function(event) {
    if ($("#edit-product-div").is(":visible")){ 
        $("#edit-product-div").fadeOut(500);
        $('#edit-product').hide().html('Editar').fadeIn(400);
    } else {
        $("#edit-product-div").fadeIn(500);
        $('#edit-product').hide().html('Dejar de editar').fadeIn(400);
    }
});