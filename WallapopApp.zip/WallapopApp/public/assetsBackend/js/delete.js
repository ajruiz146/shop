(function () {

    let deleteIndex = document.getElementsByClassName("deleteIndex");
    let formDeleteIndex = document.getElementById("formDeleteIndex");
    let deleteConfirm = document.getElementById("deleteConfirm");

    for (let i = 0; i < deleteIndex.length; i++) {
        deleteIndex[i].addEventListener('click', function() {
            let id = deleteIndex[i].dataset.id;
            let name = deleteIndex[i].dataset.name;
            modalRefresh(id, name);
            deleteConfirm.addEventListener('click', function() {
                let url = formDeleteIndex.dataset.url;
                formDeleteIndex.action = url + '/' + id;
                formDeleteIndex.submit();
            });
        });
    }
    
    function modalRefresh(id, name) {
        let refresh = document.getElementById("refresh");
        refresh.innerHTML = 'Sure to delete ' + name + ', with Id: ' + id + ' ?';
        $('#deleteConfirm').show();
    }

    let formDeleteShow = document.getElementById("formDeleteShow");
    let deleteTrue = document.getElementById("deleteTrue");
    let deleteShow = document.getElementById("deleteShow");
    
    if(deleteShow) {
        deleteShow.addEventListener('click', function() {
            let id = this.dataset.id;
            let name = this.dataset.name;
            let refresh = document.getElementById("refresh");
            refresh.innerHTML = 'Sure to delete ' + name + ', with Id: ' + id + ' ?';
            deleteTrue.addEventListener('click', function() {
                formDeleteShow.submit();
            });
        });
    }
    
    if(document.getElementById("noauthority")) {
        $('#deleteModal').modal('show');
        $('#refresh').html('Sorry, You dont have permission for this!.');
        $('#deleteConfirm').hide();
    }
    
    let nondelete = document.getElementsByClassName("nondelete");
    
    if(nondelete) {
        for(let i = 0; i < nondelete.length; i++) {
            nondelete[i].addEventListener('click', function() { 
                $('#deleteModal').modal('show');
                $('#refresh').html('Sorry, You dont have permission for this!.');
                $('#deleteConfirm').hide();
            });
        }
    }

    const selectElement = document.querySelector('#selectRows');
    if(selectElement) {
        selectElement.addEventListener('change', function(event) {
            document.querySelector('#formRows').submit();
        });
    }


    let productDelete = document.getElementsByClassName("productDelete");
    let formProductDelete = document.getElementById("formProductDelete");
    if(productDelete) {
        for(let i = 0; i < productDelete.length; i++) {
            productDelete[i].addEventListener('click', function() {
                $('#refresh').text("Seguro que quieres borrar el producto " + this.dataset.name);
                let id = this.dataset.id;
                $('#deleteModal').modal('show');
                $('#deleteTrue').on('click', function() {   
                    let url = formProductDelete.dataset.url;
                    formProductDelete.action = url + '/' + id;
                    formProductDelete.submit();
                });         
            });
        }
    }
})();
