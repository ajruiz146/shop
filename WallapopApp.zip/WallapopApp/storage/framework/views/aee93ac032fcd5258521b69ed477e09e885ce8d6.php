

<?php $__env->startSection('users'); ?>

<div class="main-body">

    <div class="row gutters-sm">
    <div class="col-md-4 mb-3">
        <div class="card">
        <div class="card-body">
            <div class="d-flex flex-column align-items-center text-center">
            <img src="data:image/jpeg;base64,<?php echo e($user->avatar); ?>" alt="Admin" class="rounded-circle" width="150">
            <div class="mt-3">
                <h4><?php echo e($user->name); ?></h4>
                <p class="text-secondary mb-1"><?php echo e($user->authority); ?></p>
                <p class="text-muted font-size-sm"><?php echo e($user->province); ?></p>
                <?php if(Auth::user()->authority === 'admin'): ?>
                    <?php if($user->authority === 'root'): ?>
                        <a href="<?php echo e(url('backend/' . $user->id . '/edit')); ?>" style="background-color:#ededed" class="btn btn-outline-primary">Edit</a>
                        <a href="#" id="deleteShow" style="background-color:#ededed" class="btn btn-outline-primary">Delete</a>
                    <?php else: ?>
                        <a href="<?php echo e(url('backend/' . $user->id . '/edit')); ?>" class="btn btn-outline-primary">Edit</a>
                        <a href="#" id="deleteShow" data-toggle="modal" data-target="#deleteModal" data-id="<?php echo e($user->id); ?>" data-name="<?php echo e($user->name); ?>" class="btn btn-outline-primary">Delete</a>
                    <?php endif; ?>
                <?php else: ?>
                    <a href="<?php echo e(url('backend/' . $user->id . '/edit')); ?>" class="btn btn-outline-primary">Edit</a>
                    <a href="#" id="deleteShow" data-toggle="modal" data-target="#deleteModal" data-id="<?php echo e($user->id); ?>" data-name="<?php echo e($user->name); ?>" class="btn btn-outline-primary">Delete</a>
                <?php endif; ?>  
            </div>
            </div>
        </div>
        </div>
    </div>
    <div class="col-md-8">
        <div class="card mb-3">
        <div class="card-body">
            <div class="row">
            <div class="col-sm-3">
                <h6 class="mb-0">Id</h6>
            </div>
            <div class="col-sm-9 text-secondary">
                <?php echo e($user->id); ?>

            </div>
            </div>
            <hr>
            <div class="row">
            <div class="col-sm-3">
                <h6 class="mb-0">Name</h6>
            </div>
            <div class="col-sm-9 text-secondary">
                <?php echo e($user->name); ?>

            </div>
            </div>
            <hr>
            <div class="row">
            <div class="col-sm-3">
                <h6 class="mb-0">Email</h6>
            </div>
            <div class="col-sm-9 text-secondary">
                <?php echo e($user->email); ?>

            </div>
            </div>
            <hr>
            <div class="row">
            <div class="col-sm-3">
                <h6 class="mb-0">Birth Day</h6>
            </div>
            <div class="col-sm-9 text-secondary">
                <?php echo e($user->birthDay); ?>

            </div>
            </div>
            <hr>
            <div class="row">
            <div class="col-sm-3">
                <h6 class="mb-0">Province</h6>
            </div>
            <div class="col-sm-9 text-secondary">
                <?php echo e($user->province); ?>

            </div>
            </div>
            <hr>
            <div class="row">
            <div class="col-sm-3">
                <h6 class="mb-0">Authority</h6>
            </div>
            <div class="col-sm-9 text-secondary">
                <?php echo e($user->authority); ?>

            </div>
            </div>
            <hr>
            <div class="row">
            <div class="col-sm-3">
                <h6 class="mb-0">Description</h6>
            </div>
            <div class="col-sm-9 text-secondary">
                <?php echo e($user->description); ?>

            </div>
            </div>
        </div>
        </div>
        </div>
    </div>
    </div>
</div>


<form id="formDeleteShow" action="<?php echo e(url('backend/' . $user->id)); ?>" method="POST">
    <?php echo method_field('delete'); ?>
    <?php echo csrf_field(); ?>
</form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal'); ?>

<div id="deleteModal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="deleteModalLiveLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="deleteModalLiveLabel">Modal Title</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            </div>
            <div class="modal-body">
                <p id="refresh">Dou you want to delete from Users List?</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn  btn-secondary" data-dismiss="modal">Close</button>
                <button id="deleteTrue" type="button" class="btn  btn-primary">Delete</button>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Quini\Apache2020\htdocs\laraveles\WallapopApp\resources\views/backend/show.blade.php ENDPATH**/ ?>