

<?php $__env->startSection('product'); ?>

<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div class="col-4">
    <div class="product" data-aos="zoom-in" data-aos-delay="0">
    <div class="product-image mb-md-3">
        <div class="product-badge badge badge-secondary"><?php echo e($product->state); ?></div><a href="<?php echo e(url('market/' . $product->id)); ?>">
        <div class=""><img class="img-fluid" src="data:image/jpeg;base64,<?php echo e($product->avatar); ?>" style="height:260px" alt="product"/></div></a>
        <div class="product-hover-overlay">
        <div><a class="text-dark text-hover-primary mr-2" href="#">
            <svg class="svg-icon svg-icon-heavy">
                <use xlink:href="#heart-1"> </use>
            </svg></a><a class="text-dark text-hover-primary text-decoration-none" href="#" data-toggle="modal" data-target="#quickView">
            <svg class="svg-icon svg-icon-heavy">
                <use xlink:href="#expand-1"> </use>
            </svg></a></div>
        </div>
    </div>
    <div class="position-relative">
        <h3 class="text-base mb-1"><a class="text-dark" href="<?php echo e(url('market/' . $product->id)); ?>"><?php echo e($product->name); ?></a></h3><span class="text-gray-500 text-sm"><?php echo e($product->state); ?></span><br /><span class="text-gray-500 text-sm"><?php echo e($product->price); ?>€</span>
        <div class="product-stars text-xs"><span class="text-gray-500 text-sm" style="margin-right:50px"><?php echo e($product->user->province); ?></span></div>
    </div>
    </div>
</div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('sidebar'); ?>
<div class="sidebar col-xl-3 col-lg-4 pr-xl-5 order-lg-1">
    
    <div class="sidebar-block px-3 px-lg-0"><a class="d-lg-none block-toggler" data-toggle="collapse" href="#categoriesMenu" aria-expanded="false" aria-controls="categoriesMenu">Product Categories<span class="block-toggler-icon"></span></a>
    <div class="expand-lg collapse" id="categoriesMenu" role="menu">
        <h5 class="sidebar-heading d-none d-lg-block">Category</h5>
        <div class="sidebar-icon-menu mt-4 mt-lg-0">  
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="sidebar-icon-menu-item active" data-toggle="collapse" data-target="#subcategories_0" aria-expanded aria-controls="subcategories_0" role="menuitem"> 
                    <div class="d-flex align-items-center">
                    <svg class="svg-icon sidebar-icon">
                        <use xlink:href="#trousers-1"> </use>
                    </svg><a class="sidebar-icon-menu-link font-weight-bold mr-2" href="<?php echo e(route('market.index', ['categoryAux' => $category, 'provinceAux' => $provinceAux, 'search' => $search])); ?>"><?php echo e($category->name); ?></a><span class="sidebar-icon-menu-count"><?php echo e($count[$index]->number); ?></span>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    </div>
    
    
    
    <div class="sidebar-block px-3 px-lg-0"><a class="d-lg-none block-toggler" data-toggle="collapse" href="#categoriesMenu" aria-expanded="false" aria-controls="categoriesMenu">Product Categories<span class="block-toggler-icon"></span></a>
    <div class="expand-lg collapse" id="categoriesMenu" role="menu">
        <h5 class="sidebar-heading d-none d-lg-block">Province</h5>
        <div class="sidebar-icon-menu mt-4 mt-lg-0"> 
            <?php $__currentLoopData = $provinces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $province): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="sidebar-icon-menu-item active" data-toggle="collapse" data-target="#subcategories_0" aria-expanded aria-controls="subcategories_0" role="menuitem"> 
                    <div class="d-flex align-items-center">
                    <svg class="svg-icon sidebar-icon">
                        <use xlink:href="#trousers-1"> </use>
                    </svg><a class="sidebar-icon-menu-link font-weight-bold mr-2" href="<?php echo e(route('market.index', ['provinceAux' => $province->province, 'categoryAux' => $categoryAux, 'search' => $search])); ?>"><?php echo e($province->province); ?></a><span class="sidebar-icon-menu-count"></span>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('nav-funtional'); ?>
    
    <div class="mr-3 mb-3">
        Showing <strong> <?php echo e($start); ?> - <?php echo e($end); ?></strong> of <strong><?php echo e($total); ?> </strong>products</div>
    <div class="mr-3 mb-3">
        <span id="row-data" data-rows="<?php echo e($rows); ?>" class="mr-2">Show</span>
        <a class="product-grid-header-show" href="<?php echo e(route('market.index', ['provinceAux' => $provinceAux, 'categoryAux' => $categoryAux, 'search' => $search, 'rows' => 6])); ?>">6</a>
        <a class="product-grid-header-show " href="<?php echo e(route('market.index', ['provinceAux' => $provinceAux, 'categoryAux' => $categoryAux, 'search' => $search, 'rows' => 12])); ?>">12</a>
        <a class="product-grid-header-show" href="<?php echo e(route('market.index', ['provinceAux' => $provinceAux, 'categoryAux' => $categoryAux, 'search' => $search, 'rows' => 18])); ?>">18</a>
        <a class="product-grid-header-show " href="#">All</a>
    </div>
    <div class="mb-3 d-flex align-items-center"><span class="d-inline-block mr-2">Sort by</span>
        <select class="selectpicker" name="sort" id="form_sort" data-style="btn-selectpicker border-0" title="">
            <option value="default" selected>Select an order</option>
            <option value="nameasc">Name Asc</option>
            <option value="namedesc">Name Desc</option>
            <option value="priceasc">Price Asc</option>
            <option value="pricedesc">Price Desc</option>
        </select>
    </div>
    <a id="pricedesc" href="<?php echo e(route('market.index', ['search' => $search, 'categoryAux' => $categoryAux, 'provinceAux' => $provinceAux, 'price' => 'desc', 'rows' => $rows])); ?>"></a>
    <a id="priceasc" href="<?php echo e(route('market.index', ['search' => $search, 'categoryAux' => $categoryAux, 'provinceAux' => $provinceAux, 'price' => 'asc', 'rows' => $rows])); ?>"></a>
    <a id="namedesc" href="<?php echo e(route('market.index', ['search' => $search, 'categoryAux' => $categoryAux, 'provinceAux' => $provinceAux, 'name' => 'desc', 'rows' => $rows])); ?>"></a>
    <a id="nameasc" href="<?php echo e(route('market.index', ['search' => $search, 'categoryAux' => $categoryAux, 'provinceAux' => $provinceAux, 'name' => 'asc', 'rows' => $rows])); ?>"></a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<script src="<?php echo e(url('assets/js/active.js')); ?>"></script>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('pagination'); ?>

    <?php echo e($products->onEachSide(2)->links()); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.allProducts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laraveles/WallapopApp/resources/views/frontend/shop.blade.php ENDPATH**/ ?>