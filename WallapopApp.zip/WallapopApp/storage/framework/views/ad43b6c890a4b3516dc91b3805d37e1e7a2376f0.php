

<?php $__env->startSection('nav'); ?>
<ul class="breadcrumb undefined">
    <li class="breadcrumb-item"><a href="<?php echo e(url('home')); ?>">Home</a></li>
    <li class="breadcrumb-item"><?php echo e($product->name); ?></li>
</ul>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('product-content'); ?>
<div class="row">
    <div class=" col-lg-5 col-xl-5 pt-4 order-2 order-lg-1 photoswipe-gallery"><a class="d-block mb-4"
            href="img/product/detail-3-gray.jpg" data-caption="Push-up Jeans 1 - Caption text" data-toggle="photoswipe"
            data-width="1200" data-height="1200"> </a>
        <?php if(!isset($images[0]->image)): ?>
        <div data-toggle="zoom" data-image="img/product/detail-3-gray.jpg"><img class="img-fluid"
                src="data:image/jpeg;base64,<?php echo e($product->avatar); ?>" alt="Push-up Jeans 1"></div></a><a
            class="d-block mb-4" href="img/product/detail-1-gray.jpg" data-caption="Push-up Jeans 2 - Caption text"
            data-toggle="photoswipe" data-width="1200" data-height="1200"> </a>
        <?php endif; ?>

        <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div data-toggle="zoom" data-image="img/product/detail-3-gray.jpg"><img class="img-fluid"
                src="data:image/jpeg;base64,<?php echo e($image->image); ?>" alt="Push-up Jeans 1"></div></a><a class="d-block mb-4"
            href="img/product/detail-1-gray.jpg" data-caption="Push-up Jeans 2 - Caption text" data-toggle="photoswipe"
            data-width="1200" data-height="1200"> </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="offset-md-2 col-lg-6 col-xl-5 pt-4 order-1 order-lg-2" style="margin-top: 100px">
            <a href="javascript:void(0)" id="edit-product" class="btn btn-outline-primary">Edit</a>
            <a href="#" id="deleteShow" data-toggle="modal" data-target="#deleteModal" data-id="<?php echo e($product->id); ?>" data-name="<?php echo e($product->name); ?>" class="btn btn-outline-primary">Delete</a>
 
            <div id="edit-product-div">
                <form action="<?php echo e(url('product/' . $product->id)); ?>" method="POST" enctype='multipart/form-data'>
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('put'); ?>
                    <div class="form-group">
                        <input type="hidden" class="form-control" id="iduser" name="iduser" value="<?php echo e(auth()->user()->id); ?>">
                    </div>

                    <div class="form-group">
                        <label for="name">Product Name</label>
                        <input type="text" class="form-control" id="name" name="name" placeholder="Enter name"
                            value="<?php echo e(old('name', $product->name)); ?>">
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="error">*<?php echo e($message); ?>*</div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group">
                        <label for="rol">Category</label>
                        <select required name="idcategory" id="idcategory" class="form-control">
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($category->id); ?>" <?php echo e($product->idcategory == $category->id ? 'selected' : ''); ?> <?php echo e(old('idcategory') == $category->id ? 'selected' : ''); ?>><?php echo e($category->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['authority'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="error">*<?php echo e($message); ?>*</div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group">
                        <label for="text">Use</label>
                        <input type="text" class="form-control" id="use" name="use" placeholder="Enter use"
                            value="<?php echo e(old('use', $product->use)); ?>">
                        <?php $__errorArgs = ['use'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="error">*<?php echo e($message); ?>*</div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>


                    <div class="form-group">
                        <label for="state">State</label>
                        <input type="text" class="form-control" id="state" name="state" placeholder="State"
                            value="<?php echo e(old('state', $product->state)); ?>">
                        <?php $__errorArgs = ['state'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="error">*<?php echo e($message); ?>*</div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>


                    <div class="form-group">
                        <label for="price">Price</label>
                        <input type="text" class="form-control" id="price" name="price" placeholder="€"
                            value="<?php echo e(old('price', $product->price)); ?>">
                        <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="error">*<?php echo e($message); ?>*</div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group">
                        <label for="description">Description</label>
                        <textarea class="form-control" id="description" name="description"
                            rows="4"><?php echo e(old('description', $product->description)); ?></textarea>
                        <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="error">*<?php echo e($message); ?>*</div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group">
                        <label for="image">Images</label> <br>
                        <input type="file" id="image" name="image[]" multiple>
                        <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="error">*<?php echo e($message); ?>*</div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <button type="submit" class="btn  btn-primary">Submit</button>
                </form>
            </div>
    
    
        <div class="sticky-top" style="top: 140px;">
            <div class="row" style="align-items: center">
                <h1 class="mb-4 col-lg-7" style="text-align:middle;"><?php echo e($product->name); ?></h1>
                <div class="propietario col-lg-5">
                    <small class="mb-4 text-muted" style="margin-left: 60px;">Owner</small>
                    <img style="height: 130px; border-radius: 50%; margin-left: 17px;"
                    src="data:image/jpeg;base64,<?php echo e($product->user->avatar); ?>" alt="Push-up Jeans 1">
                    
                    <p class="mb-4" style="text-align:center;"><?php echo e($product->user->name); ?></p>
                    
                </div>
            </div>
            <div class="d-flex flex-column flex-sm-row align-items-sm-center justify-content-sm-between mb-4">
                <ul class="list-inline mb-2 mb-sm-0">
                    <li class="list-inline-item h4 font-weight-light mb-0" style="color: #bcac76">Price: <?php echo e($product->price); ?>€</li>
                </ul>
                <div class="d-flex align-items-center text-sm">
                    <span class="text-muted text-uppercase" style="margin-right: -20px"><?php echo e($products->count()); ?>

                        products on sale</span>
                </div>
            </div>

            <h6 class="detail-option-heading">Description:</h6>
            <p class="mb-4 text-muted"><?php echo e($product->description); ?></p>
            <div class="row" style="padding: 30px 0;">
                <div class="col-lg-6">
                    <h6 class="detail-option-heading">Category:</h6>
                    <p class="mb-4 text-muted"><?php echo e($product->category->name); ?></p>

                    <h6 class="detail-option-heading">Use:</h6>
                    <p class="mb-4 text-muted"><?php echo e($product->use); ?></p>
                </div>
                <div class="col-lg-6">
                    <h6 class="detail-option-heading">State:</span></h6>
                    <p class="mb-4 text-muted"><?php echo e($product->state); ?></p>

                    <h6 class="detail-option-heading">Date:</span></h6>
                    <p class="mb-4 text-muted"><?php echo e($product->date); ?></p>
                </div>
            </div>
            <div class="input-group w-100 mb-4">

                <div class="input-group-append flex-grow-1">
                    <button class="btn btn-dark btn-block" type="submit"> <i
                            class="fa fa-shopping-cart mr-2"></i>Contact</button>
                </div>
            </div>
            <div class="row mb-4">
                <div class="col-6"><a href="#"> <i class="far fa-heart mr-2"></i>Add to wishlist</a></div>
                <div class="col-6 text-right">
                    <ul class="list-inline mb-0">
                        <li class="list-inline-item mr-2"><a class="text-dark text-hover-primary" href="#"><i
                                    class="fab fa-facebook-f"> </i></a></li>
                        <li class="list-inline-item"><a class="text-dark text-hover-primary" href="#"><i
                                    class="fab fa-twitter"> </i></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>

<form id="formDeleteShow" action="<?php echo e(url('product/' . $product->id)); ?>" method="POST">
    <?php echo method_field('delete'); ?>
    <?php echo csrf_field(); ?>
</form>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('modal'); ?>

<div id="deleteModal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="deleteModalLiveLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="deleteModalLiveLabel">Modal Title</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            </div>
            <div class="modal-body">
                <p id="refresh">Dou you want to delete from Users List?</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn  btn-secondary" data-dismiss="modal">Close</button>
                <button id="deleteTrue" type="button" class="btn  btn-primary">Delete</button>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.individualproduct', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Quini\Apache2020\htdocs\laraveles\WallapopApp\resources\views/frontend/individual.blade.php ENDPATH**/ ?>