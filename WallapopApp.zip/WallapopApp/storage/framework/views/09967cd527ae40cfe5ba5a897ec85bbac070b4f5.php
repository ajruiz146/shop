<?php $__env->startSection('register'); ?>
<div class="container" style="padding-bottom: 100px">
        <div class="col-lg-8 offset-lg-2">
            <div class="card">
                <div class="card-header py-4 px-5">
                    <h5 class="mb-0">New account</h5>
                </div>
                <div class="card-body p-5">
                    <p class="lead">Not our registered customer yet?</p>
                    <p class="text-muted text-sm">With registration with us new world of Wallapop Market, fantastic products and much more opens to you! The whole process will not take you more than a minute!</p>
                    <hr class="my-4">
                    <div class="container">

                    <form method="POST" action="<?php echo e(route('register')); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>

                        <div class="form-group row">
                            <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Name')); ?></label>

                            <div class="col-md-6">
                                <input id="name" type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name" value="<?php echo e(old('name')); ?>" required autocomplete="name" autofocus>
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="error">*<?php echo e($message); ?>*</div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="email" class="col-md-4 col-form-label text-md-right"><?php echo e(__('E-Mail Address')); ?></label>

                            <div class="col-md-6">
                                <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email">

                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="error">*<?php echo e($message); ?>*</div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="password" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Password')); ?></label>

                            <div class="col-md-6">
                                <input id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="new-password">

                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="error">*<?php echo e($message); ?>*</div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="password-confirm" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Confirm Password')); ?></label>

                            <div class="col-md-6">
                                <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required autocomplete="new-password">
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="birthDay" class="col-md-4 col-form-label text-md-right">Birth Day</label>

                            <div class="col-md-6">
                                <input id="birthDay" type="date" class="form-control <?php $__errorArgs = ['birthDay'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="birthDay" value="<?php echo e(old('birthDay')); ?>" required>

                                <?php $__errorArgs = ['birthDay'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="error">*<?php echo e($message); ?>*</div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="province" class="col-md-4 col-form-label text-md-right">Province</label>

                            <div class="col-md-6">
                                <select required name="province" id="province" class="form-control <?php $__errorArgs = ['province'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                    <option value="">Select Province</option>
                                    <option value="Álava/Araba" <?php echo e(old('province') == 'Álava/Araba' ? 'selected' : ''); ?>>Álava/Araba</option>
                                    <option value="Albacete" <?php echo e(old('province') == 'Albacete' ? 'selected' : ''); ?>>Albacete</option>
                                    <option value="Alicante" <?php echo e(old('province') == 'Alicante' ? 'selected' : ''); ?>>Alicante</option>
                                    <option value="Almería" <?php echo e(old('province') == 'Almería' ? 'selected' : ''); ?>>Almería</option>
                                    <option value="Asturias" <?php echo e(old('province') == 'Asturias' ? 'selected' : ''); ?>>Asturias</option>
                                    <option value="Ávila" <?php echo e(old('province') == 'Ávila' ? 'selected' : ''); ?>>Ávila</option>
                                    <option value="Badajoz" <?php echo e(old('province') == 'Badajoz' ? 'selected' : ''); ?>>Badajoz</option>
                                    <option value="Baleares" <?php echo e(old('province') == 'Baleares' ? 'selected' : ''); ?>>Baleares</option>
                                    <option value="Barcelona" <?php echo e(old('province') == 'Barcelona' ? 'selected' : ''); ?>>Barcelona</option>
                                    <option value="Burgos" <?php echo e(old('province') == 'Burgos' ? 'selected' : ''); ?>>Burgos</option>
                                    <option value="Cáceres" <?php echo e(old('province') == 'Cáceres' ? 'selected' : ''); ?>>Cáceres</option>
                                    <option value="Cádiz" <?php echo e(old('province') == 'Cádiz' ? 'selected' : ''); ?>>Cádiz</option>
                                    <option value="Cantabria" <?php echo e(old('province') == 'Cantabria' ? 'selected' : ''); ?>>Cantabria</option>
                                    <option value="Castellón" <?php echo e(old('province') == 'Castellón' ? 'selected' : ''); ?>>Castellón</option>
                                    <option value="Ceuta" <?php echo e(old('province') == 'Ceuta' ? 'selected' : ''); ?>>Ceuta</option>
                                    <option value="Ciudad Real" <?php echo e(old('province') == 'Ciudad Real' ? 'selected' : ''); ?>>Ciudad Real</option>
                                    <option value="Córdoba" <?php echo e(old('province') == 'Córdoba' ? 'selected' : ''); ?>>Córdoba</option>
                                    <option value="Cuenca" <?php echo e(old('province') == 'Cuenca' ? 'selected' : ''); ?>>Cuenca</option>
                                    <option value="Gerona/Girona" <?php echo e(old('province') == 'Gerona/Girona' ? 'selected' : ''); ?>>Gerona/Girona</option>
                                    <option value="Granada" <?php echo e(old('province') == 'Granada' ? 'selected' : ''); ?>>Granada</option>
                                    <option value="Guadalajara" <?php echo e(old('province') == 'Guadalajara' ? 'selected' : ''); ?>>Guadalajara</option>
                                    <option value="Guipúzcoa/Gipuzkoa" <?php echo e(old('province') == 'Guipúzcoa/Gipuzkoa' ? 'selected' : ''); ?>>Guipúzcoa/Gipuzkoa</option>
                                    <option value="Huelva" <?php echo e(old('province') == 'Huelva' ? 'selected' : ''); ?>>Huelva</option>
                                    <option value="Huesca" <?php echo e(old('province') == 'Huesca' ? 'selected' : ''); ?>>Huesca</option>
                                    <option value="Jaén" <?php echo e(old('province') == 'Jaén' ? 'selected' : ''); ?>>Jaén</option>
                                    <option value="La Coruña/A Coruña" <?php echo e(old('province') == 'La Coruña/A Coruña' ? 'selected' : ''); ?>>La Coruña/A Coruña</option>
                                    <option value="La Rioja" <?php echo e(old('province') == 'La Rioja' ? 'selected' : ''); ?>>La Rioja</option>
                                    <option value="Las Palmas" <?php echo e(old('province') == 'Las Palmas' ? 'selected' : ''); ?>>Las Palmas</option>
                                    <option value="León" <?php echo e(old('province') == 'León' ? 'selected' : ''); ?>>León</option>
                                    <option value="Lérida/Lleida" <?php echo e(old('province') == 'Lérida/Lleida' ? 'selected' : ''); ?>>Lérida/Lleida</option>
                                    <option value="Lugo" <?php echo e(old('province') == 'Lugo' ? 'selected' : ''); ?>>Lugo</option>
                                    <option value="Madrid" <?php echo e(old('province') == 'Madrid' ? 'selected' : ''); ?>>Madrid</option>
                                    <option value="Málaga" <?php echo e(old('province') == 'Málaga' ? 'selected' : ''); ?>>Málaga</option>
                                    <option value="Melilla" <?php echo e(old('province') == 'Melilla' ? 'selected' : ''); ?>>Melilla</option>
                                    <option value="Murcia" <?php echo e(old('province') == 'Murcia' ? 'selected' : ''); ?>>Murcia</option>
                                    <option value="Navarra" <?php echo e(old('province') == 'Navarra' ? 'selected' : ''); ?>>Navarra</option>
                                    <option value="Orense/Ourense" <?php echo e(old('province') == 'Orense/Ourense' ? 'selected' : ''); ?>>Orense/Ourense</option>
                                    <option value="Palencia" <?php echo e(old('province') == 'Palencia' ? 'selected' : ''); ?>>Palencia</option>
                                    <option value="Pontevedra" <?php echo e(old('province') == 'Pontevedra' ? 'selected' : ''); ?>>Pontevedra</option>
                                    <option value="Salamanca" <?php echo e(old('province') == 'Salamanca' ? 'selected' : ''); ?>>Salamanca</option>
                                    <option value="Segovia" <?php echo e(old('province') == 'Segovia' ? 'selected' : ''); ?>>Segovia</option>
                                    <option value="Sevilla" <?php echo e(old('province') == 'Sevilla' ? 'selected' : ''); ?>>Sevilla</option>
                                    <option value="Soria" <?php echo e(old('province') == 'Soria' ? 'selected' : ''); ?>>Soria</option>
                                    <option value="Tarragona" <?php echo e(old('province') == 'Tarragona' ? 'selected' : ''); ?>>Tarragona</option>
                                    <option value="Tenerife" <?php echo e(old('province') == 'Tenerife' ? 'selected' : ''); ?>>Tenerife</option>
                                    <option value="Teruel" <?php echo e(old('province') == 'Teruel' ? 'selected' : ''); ?>>Teruel</option>
                                    <option value="Toledo" <?php echo e(old('province') == 'Toledo' ? 'selected' : ''); ?>>Toledo</option>
                                    <option value="Valencia" <?php echo e(old('province') == 'Valencia' ? 'selected' : ''); ?>>Valencia</option>
                                    <option value="Valladolid" <?php echo e(old('province') == 'Valladolid' ? 'selected' : ''); ?>>Valladolid</option>
                                    <option value="Vizcaya/Bizkaia" <?php echo e(old('province') == 'Vizcaya/Bizkaia' ? 'selected' : ''); ?>>Vizcaya/Bizkaia</option>
                                    <option value="Zamora" <?php echo e(old('province') == 'Zamora' ? 'selected' : ''); ?>>Zamora</option>
                                    <option value="Zaragoza" <?php echo e(old('province') == 'Zaragoza' ? 'selected' : ''); ?>>Zaragoza</option>
                                </select>
                                <?php $__errorArgs = ['province'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="error">*<?php echo e($message); ?>*</div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="description" class="col-md-4 col-form-label text-md-right">Description</label>

                            <div class="col-md-6">
                                <textarea id="description" class="form-control <?php $__errorArgs = ['birthDay'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="description" required><?php echo e(old('description')); ?></textarea>

                                <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="error">*<?php echo e($message); ?>*</div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="avatar" class="col-md-4 col-form-label text-md-right">Profile Pic</label>

                            <div class="col-md-6">
                                <input id="avatar" type="file" class="form-control <?php $__errorArgs = ['avatar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="avatar">

                                <?php $__errorArgs = ['avatar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>


                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    <?php echo e(__('Register')); ?>

                                </button>
                            </div>
                        </div>
                        
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Quini\Apache2020\htdocs\laraveles\WallapopApp\resources\views/auth/register.blade.php ENDPATH**/ ?>