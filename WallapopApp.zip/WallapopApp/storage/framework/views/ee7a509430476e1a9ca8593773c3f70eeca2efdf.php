

<?php $__env->startSection('users'); ?>

<div class="main-body">
    <div class="row gutters-sm">
        <div class="col-md-4 mb-3">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex flex-column align-items-center text-center">
                        <div class="card p-3 bg-white" style="margin:20px">
                            <div class="row">
                                <a style="padding-left: 20px;" href="<?php echo e(url('backend/product/' . $product->id. '/edit')); ?>"><i style="font-size:1.2rem;" class="feather icon-edit"></i></a>
                                <a href="javascript:void(0)" class="productDelete" data-id="<?php echo e($product->id); ?>" data-name="<?php echo e($product->name); ?>" data-id="<?php echo e($user->id); ?>" data-name="<?php echo e($user->name); ?>"><i style="padding: 3px; margin-left: 2px; font-size:1.2rem;" class="feather icon-trash-2"></i></a> 
                            </div>
                            
                            <div class="about-product text-center mt-2"><img src="data:image/jpeg;base64,<?php echo e($product->avatar); ?>" width="300">
                                <div>
                                    <h4><?php echo e($product->name); ?></h4>
                                    <h6 class="mt-0 text-black-50"><?php echo e($product->category->name); ?></h6>
                                </div>
                            </div>
                            <div class="stats mt-2">
                                <div class="d-flex justify-content-between p-price"><span>Use:</span><span><?php echo e($product->use); ?></span></div>
                                <div class="d-flex justify-content-between p-price"><span>State:</span><span><?php echo e($product->state); ?></span></div>
                                <div class="d-flex justify-content-between p-price"><span>Date:</span><span><?php echo e($product->date); ?></span></div>
                            </div>
                        
                            <div class="d-flex justify-content-between total font-weight-bold mt-4"><span>Total</span><span><?php echo e($product->price); ?>€</span></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-8">
            <div class="card">
                <div class="card-body">
                    <form action="<?php echo e(url('backend/product/' . $product->id)); ?>" method="POST" enctype='multipart/form-data'>
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('put'); ?>
                        <div class="form-group">
                            <input type="hidden" class="form-control" id="iduser" name="iduser" value="<?php echo e(auth()->user()->id); ?>">
                        </div>

                        <div class="form-group">
                            <label for="name">Product Name</label>
                            <input type="text" class="form-control" id="name" name="name" placeholder="Enter name"
                                value="<?php echo e(old('name', $product->name)); ?>">
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="error">*<?php echo e($message); ?>*</div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group">
                            <label for="rol">Category</label>
                            <select required name="idcategory" id="idcategory" class="form-control">
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($category->id); ?>" <?php echo e($product->idcategory == $category->id ? 'selected' : ''); ?> <?php echo e(old('idcategory') == $category->id ? 'selected' : ''); ?>><?php echo e($category->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['authority'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="error">*<?php echo e($message); ?>*</div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group">
                            <label for="text">Use</label>
                            <input type="text" class="form-control" id="use" name="use" placeholder="Enter use"
                                value="<?php echo e(old('use', $product->use)); ?>">
                            <?php $__errorArgs = ['use'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="error">*<?php echo e($message); ?>*</div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>


                        <div class="form-group">
                            <label for="state">State</label>
                            <input type="text" class="form-control" id="state" name="state" placeholder="State"
                                value="<?php echo e(old('state', $product->state)); ?>">
                            <?php $__errorArgs = ['state'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="error">*<?php echo e($message); ?>*</div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>


                        <div class="form-group">
                            <label for="price">Price</label>
                            <input type="text" class="form-control" id="price" name="price" placeholder="€"
                                value="<?php echo e(old('price', $product->price)); ?>">
                            <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="error">*<?php echo e($message); ?>*</div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group">
                            <label for="description">Description</label>
                            <textarea class="form-control" id="description" name="description"
                                rows="4"><?php echo e(old('description', $product->description)); ?></textarea>
                            <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="error">*<?php echo e($message); ?>*</div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group">
                            <label for="image">Images</label> <br>
                            <input type="file" id="image" name="image[]" multiple>
                            <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="error">*<?php echo e($message); ?>*</div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <button type="submit" class="btn  btn-primary">Submit</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<form id="formDeleteShow" action="<?php echo e(url('backend/' . $user->id)); ?>" method="POST">
    <?php echo method_field('delete'); ?>
    <?php echo csrf_field(); ?>
</form>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal'); ?>

<div id="deleteModal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="deleteModalLiveLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="deleteModalLiveLabel">Modal Title</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            </div>
            <div class="modal-body">
                <p id="refresh">Dou you want to delete from Users List?</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn  btn-secondary" data-dismiss="modal">Close</button>
                <button id="deleteTrue" type="button" class="btn  btn-primary">Delete</button>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laraveles/WallapopApp/resources/views/backend/editproduct.blade.php ENDPATH**/ ?>