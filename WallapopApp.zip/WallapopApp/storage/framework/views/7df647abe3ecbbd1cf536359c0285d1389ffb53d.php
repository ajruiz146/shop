

<?php $__env->startSection('users'); ?>

<div class="card">
    <div class="card-header">
        <h5>Users Administration</h5>
    </div>
    <div class="card-body table-border-style">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>
                            Avatar
                        
                        </th>
                        <th>
                            #
                            <a href="<?php echo e(route('backend.index', ['search' => $search , 'sort' => 'asc', 'orderby' => 0])); ?>">↓</a>
                            <a href="<?php echo e(route('backend.index', ['search' => $search , 'sort' => 'desc', 'orderby' => 0])); ?>">↑</a>
                        </th>
                        <th>
                            Name
                            <a href="<?php echo e(route('backend.index', ['search' => $search , 'sort' => 'asc', 'orderby' => 1])); ?>">↓</a>
                            <a href="<?php echo e(route('backend.index', ['search' => $search , 'sort' => 'desc', 'orderby' => 1])); ?>">↑</a>
                        </th>
                        <th>
                            Birth Day
                            <a href="<?php echo e(route('backend.index', ['search' => $search , 'sort' => 'asc', 'orderby' => 2])); ?>">↓</a>
                            <a href="<?php echo e(route('backend.index', ['search' => $search , 'sort' => 'desc', 'orderby' => 2])); ?>">↑</a>
                        </th>
                        <th>
                            Province
                            <a href="<?php echo e(route('backend.index', ['search' => $search , 'sort' => 'asc', 'orderby' => 3])); ?>">↓</a>
                            <a href="<?php echo e(route('backend.index', ['search' => $search , 'sort' => 'desc', 'orderby' => 3])); ?>">↑</a>
                        </th>
                        <th>Show</th>
                        <th>Edit</th>
                        <th>Delete</th>
                    </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><img class="avatar" src="data:image/jpeg;base64,<?php echo e($user->avatar); ?>"></td>
                        <td><?php echo e($user->id); ?></td>
                        <td><?php echo e($user->name); ?></td>
                        <td><?php echo e($user->birthDay); ?></td>
                        <td><?php echo e($user->province); ?></td>

                        <td><a href="<?php echo e(url('backend/' . $user->id)); ?>"><i class="feather icon-eye"></a></td>
                        <?php if(Auth::user()->authority === 'admin'): ?>
                            <?php if($user->authority === 'root'): ?>
                            <td><a href="<?php echo e(url('backend/' . $user->id . '/edit')); ?>"><i style="color:grey" class="feather icon-edit"></a></td>
                            <td><a href="#" class="deleteIndex nondelete"><i style="color:grey" class="feather icon-user-x"></a></td>
                            <?php else: ?>
                            <td><a href="<?php echo e(url('backend/' . $user->id . '/edit')); ?>"><i class="feather icon-edit"></a></td>
                            <td><a href="#" data-toggle="modal" data-target="#deleteModal" data-id="<?php echo e($user->id); ?>" data-name="<?php echo e($user->name); ?>" class="deleteIndex"><i class="feather icon-user-x"></a></td>
                            <?php endif; ?>
                        <?php else: ?> 
                        <td><a href="<?php echo e(url('backend/' . $user->id . '/edit')); ?>"><i class="feather icon-edit"></a></td>
                        <td><a href="#" data-toggle="modal" data-target="#deleteModal" data-id="<?php echo e($user->id); ?>" data-name="<?php echo e($user->name); ?>" class="deleteIndex"><i class="feather icon-user-x"></a></td>
                        <?php endif; ?>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            
        </div>
    </div>
</div>
<div class="row">
    <div class="col-lg-6">
        <?php echo e($users->onEachSide(2)->links()); ?>

    </div>
    <div class="col-lg-5">
        <div class="float-right">
            <form class="form-inline" id="formRows">
                <label for="selectRows">Select rows number: </label>
                <select name="rows" class="form-control" id="selectRows">
                    <option <?php if($rows==2): ?> selected <?php endif; ?>>2</option>
                    <option <?php if($rows==3): ?> selected <?php endif; ?>>3</option>
                    <option <?php if($rows==5): ?> selected <?php endif; ?>>5</option>
                    <option <?php if($rows==10): ?> selected <?php endif; ?>>10</option>
                </select>
                <input type="hidden" name="orderby" value="<?php echo e($orderby); ?>">
                <input type="hidden" name="sort" value="<?php echo e($sort); ?>">
                <input type="hidden" name="search" value="<?php echo e($search); ?>">
            </form>
        </div>
    </div>
</div>


<form id="formDeleteIndex" action="" method="POST" data-url="<?php echo e(url('backend')); ?>">
    <?php echo method_field('delete'); ?>
    <?php echo csrf_field(); ?>
</form>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal'); ?>

<div id="deleteModal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="deleteModalLiveLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="deleteModalLiveLabel">Modal Title</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            </div>
            <div class="modal-body">
                <p id="refresh">Dou you want to delete from Users List?</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn  btn-secondary" data-dismiss="modal">Close</button>
                <button id="deleteConfirm" type="button" class="btn  btn-primary">Delete</button>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>



<?php if(Session::has('noauthority')): ?>
    <div id="noauthority"></div>
<?php endif; ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Quini\Apache2020\htdocs\laraveles\WallapopApp\resources\views/backend/index.blade.php ENDPATH**/ ?>