<!DOCTYPE html>
<html lang="en">
  
<!-- Mirrored from demo.bootstrapious.com/varkala/1-2/customer-login.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 30 Jan 2021 21:53:46 GMT -->
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Wallapop</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="all,follow">
    <!-- Custom font-->
    <link rel="stylesheet" href="<?php echo e(url('assets/fonts/stylesheet.e9dc714d.css')); ?>">
    <!-- Swiper-->
    <link rel="stylesheet" href="<?php echo e(url('assets/vendor/swiper/css/swiper.min.css')); ?>">
    <!-- AOS - AnimationOnScroll-->
    <link rel="stylesheet" href="<?php echo e(url('assets/vendor/aos/aos.css')); ?>">
    <!-- Custom Scrollbar-->
    <link rel="stylesheet" href="<?php echo e(url('assets/vendor/malihu-custom-scrollbar-plugin/jquery.mCustomScrollbar.css')); ?>">
    <!-- Theme stylesheet-->
    <link rel="stylesheet" href="<?php echo e(url('assets/css/style.default.d1b89a2d.css')); ?>" id="theme-stylesheet">
    <!-- Custom stylesheet - for your changes-->
    <link rel="stylesheet" href="<?php echo e(url('assets/css/custom.0a822280.css')); ?>">
    <!-- Favicon-->
    <link rel="shortcut icon" href="<?php echo e(url('assets/1-2/img/favicon.png')); ?>">
    <!-- FontAwesome-->
    <link rel="stylesheet" href="<?php echo e(url('assets/css/all.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(url('assetsBackend/css/style2.css')); ?>">
    <!-- Tweaks for older IEs--><!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->
  </head>
  <body>
    <!-- navbar-->

    <!-- Hero Section-->
    <section class="hero py-6">
      <div class="container">
        <!-- Breadcrumbs -->
        <ol class="breadcrumb pl-0 ">
          <li class="breadcrumb-item"><a href="<?php echo e(url('login')); ?>">Login</a></li>
          <li class="breadcrumb-item active"><a href="<?php echo e(url('register')); ?>">Register</a></li>
        </ol>
        <!-- Hero Content-->
        <div class="hero-content">
          <h1 class="hero-heading mb-3">Customer zone</h1>
          <div><p class="text-muted">You can use the navbar-modal link or this page for customers' sign in.</p></div>
        </div>
      </div>
    </section>
    <!-- customer login-->
        <?php echo $__env->yieldContent('register'); ?>
        <?php echo $__env->yieldContent('modal'); ?>
    <!-- Footer-->
    <footer>
      <!-- Services block-->
      <div class="py-5 py-lg-6 bg-gray-100">
        <div class="container">
          <div class="row">
            <div class="col-lg-3 col-sm-6 py-4 service-column">
              <svg class="svg-icon service-icon">
                <use xlink:href="#delivery-time-1"> </use>
              </svg>
              <div class="service-text">
                <h6 class="text-sm mb-1">Free shipping &amp; return</h6>
                <p class="text-muted font-weight-light text-sm mb-0">Free Shipping over $300</p>
              </div>
            </div>
            <div class="col-lg-3 col-sm-6 py-4 service-column">
              <svg class="svg-icon service-icon">
                <use xlink:href="#money-1"> </use>
              </svg>
              <div class="service-text">
                <h6 class="text-sm mb-1">Money back guarantee</h6>
                <p class="text-muted font-weight-light text-sm mb-0">30 Days Money Back Guarantee</p>
              </div>
            </div>
            <div class="col-lg-3 col-sm-6 py-4 service-column">
              <svg class="svg-icon service-icon">
                <use xlink:href="#special-price-1"> </use>
              </svg>
              <div class="service-text">
                <h6 class="text-sm mb-1">Best prices</h6>
                <p class="text-muted font-weight-light text-sm mb-0">Always the best prices</p>
              </div>
            </div>
            <div class="col-lg-3 col-sm-6 py-4 service-column">
              <svg class="svg-icon service-icon">
                <use xlink:href="#customer-support-1"> </use>
              </svg>
              <div class="service-text">
                <h6 class="text-sm mb-1">020-800-456-747</h6>
                <p class="text-muted font-weight-light text-sm mb-0">24/7 Available Support</p>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- Main block - menus, subscribe form-->

    </footer>
    <!-- /Footer end-->
    <!-- JavaScript files-->
    <script>
      // ------------------------------------------------------- //
      //   Inject SVG Sprite - 
      //   see more here 
      //   https://css-tricks.com/ajaxing-svg-sprite/
      // ------------------------------------------------------ //
      function injectSvgSprite(path) {
      
          var ajax = new XMLHttpRequest();
          ajax.open("GET.html", path, true);
          ajax.send();
          ajax.onload = function(e) {
          var div = document.createElement("div");
          div.className = 'd-none';
          div.innerHTML = ajax.responseText;
          document.body.insertBefore(div, document.body.childNodes[0]);
          }
      }
      // this is set to Bootstrapious website as you cannot 
      // inject local SVG sprite (using only 'icons/orion-svg-sprite.01205608.svg' path)
      // while using file:// protocol
      // pls don't forget to change to your domain :)
      injectSvgSprite('https://demo.bootstrapious.com/varkala/1-1/icons/orion-svg-sprite.svg'); 
      injectSvgSprite('https://demo.bootstrapious.com/varkala/1-1/icons/varkala-clothes.svg'); 
      injectSvgSprite('https://demo.bootstrapious.com/varkala/1-1/img/shape/blob-sprite.svg'); 
      
    </script>
    <!-- jQuery-->
    <script src="<?php echo e(url('assets/vendor/jquery/jquery.min.js')); ?>"></script>
    <!-- Bootstrap Bundle -->
    <script src="<?php echo e(url('assets/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
    <!-- Swiper Carousel                       -->
    <script src="<?php echo e(url('assets/vendor/swiper/js/swiper.min.js')); ?>"></script>
    <!-- Bootstrap Select-->
    <script src="<?php echo e(url('assets/vendor/bootstrap-select/js/bootstrap-select.min.js')); ?>"></script>
    <!-- AOS - AnimationOnScroll-->
    <script src="<?php echo e(url('assets/vendor/aos/aos.js')); ?>"></script>
    <!-- Custom Scrollbar-->
    <script src="<?php echo e(url('assets/vendor/malihu-custom-scrollbar-plugin/jquery.mCustomScrollbar.concat.min.js')); ?>"></script>
    <script src="<?php echo e(url('assets/js/custom-scrollbar-init.f148089f.js')); ?>"></script>
    <!-- Smooth scroll-->
    <script src="<?php echo e(url('assets/vendor/smooth-scroll/smooth-scroll.polyfills.min.js')); ?>"></script>
    <!-- Object Fit Images - Fallback for browsers that don't support object-fit-->
    <script src="<?php echo e(url('assets/vendor/object-fit-images/ofi.min.js')); ?>"></script>
    <!-- Some theme config-->
    <script>
      var options = {
          navbarExpandPx: 992
      }
      
    </script>
    <!-- Main Theme files-->
    <script src="<?php echo e(url('assets/js/sliders-init.1db6fb07.js')); ?>"></script>
    <script src="<?php echo e(url('assets/js/theme.fe2c17cd.js')); ?>"></script>
    <script src="<?php echo e(url('assets/js/loginScript.js')); ?>"></script>
  </body>

<!-- Mirrored from demo.bootstrapious.com/varkala/1-2/customer-login.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 30 Jan 2021 21:53:46 GMT -->
</html><?php /**PATH /var/www/html/laraveles/WallapopApp/resources/views/layouts/login.blade.php ENDPATH**/ ?>