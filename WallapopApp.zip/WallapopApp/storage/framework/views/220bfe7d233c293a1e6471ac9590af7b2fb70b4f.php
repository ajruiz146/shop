

<?php $__env->startSection('username'); ?>

    <h5>Chat with <?php echo e($theOtherUser->name); ?><span class="chat_date"> | For: <?php echo e($chats[0]->product->name); ?></span></h5>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('information'); ?>
<div class="container">
    <div class="offset-md-2 col-md-8">
        <div class="messaging">
            <div class="inbox_msg">
                <div class="mesgs">
                    <div id="msg_history" class="msg_history">
                        <?php $__currentLoopData = $chats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($chat->idemisor == $emisor): ?>
                        <div class="outgoing_msg">
                            <div id="sent" class="sent_msg">
                                <p><?php echo e($chat->message); ?></p>
                                <span class="time_date"><?php echo e($chat->created_at->format('G : i | d M')); ?></span>
                            </div>
                        </div>
                        <?php else: ?>
                        <div class="incoming_msg">
                            <div class="incoming_msg_img"> <img src="data:image/jpeg;base64,<?php echo e($theOtherUser->avatar); ?>"
                                    alt="sunil"> </div>
                            <div class="received_msg">
                                <div id="received" class="received_withd_msg">
                                    <p><?php echo e($chat->message); ?></p>
                                    <span class="time_date"><?php echo e($chat->created_at->format('G : i | d M')); ?></span>
                                </div>
                            </div>
                        </div>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                    <form action="<?php echo e(url('chat')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="type_msg">
                            <div class="input_msg_write">
                                <input id="message" name="message" type="text" class="write_msg"
                                    placeholder="Type a message" />
                                <button class="msg_send_btn" type="submit"><i class="fa fa-paper-plane-o" aria-hidden="true"></i></button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<script src="<?php echo e(url('assets/js/scroll.js')); ?>"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laraveles/WallapopApp/resources/views/frontend/chat.blade.php ENDPATH**/ ?>