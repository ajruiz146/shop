

<?php $__env->startSection('users'); ?>

<div class="card">
    <div class="card-body">
        <h5>Create User</h5>
        <hr>
        <div class="row">
            <div class="col-md-6">
                <form action="<?php echo e(url('backend')); ?>" method="POST" enctype='multipart/form-data'>
                    <?php echo csrf_field(); ?>

                    <div class="form-group">
                        <label for="name">Name</label>
                        <input type="text" class="form-control" id="name" name="name" placeholder="Enter name" value="<?php echo e(old('name')); ?>">
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="error">*<?php echo e($message); ?>*</div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    

                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="email" class="form-control" id="email" name="email" placeholder="Enter email" value="<?php echo e(old('email')); ?>">
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="error">*<?php echo e($message); ?>*</div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    

                    <div class="form-group">
                        <label for="password">Password</label>
                        <input type="password" class="form-control" id="password" name="password" placeholder="Password">
                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="error">*<?php echo e($message); ?>*</div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    

                    <div class="form-group">
                        <label for="birthDay">Birth Day</label>
                        <input type="date" class="form-control" id="birthDay" name="birthDay" value="<?php echo e(old('birthDay')); ?>">
                        <?php $__errorArgs = ['birthDay'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="error">*<?php echo e($message); ?>*</div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    

                    <div class="form-group">
                        <label for="province">Province</label>
                        <select required name="province" id="province" class="form-control">
                            <option value="">Select Province</option>
                            <option value="Álava/Araba" <?php echo e(old('province') == 'Álava/Araba' ? 'selected' : ''); ?>>Álava/Araba</option>
                            <option value="Albacete" <?php echo e(old('province') == 'Albacete' ? 'selected' : ''); ?>>Albacete</option>
                            <option value="Alicante" <?php echo e(old('province') == 'Alicante' ? 'selected' : ''); ?>>Alicante</option>
                            <option value="Almería" <?php echo e(old('province') == 'Almería' ? 'selected' : ''); ?>>Almería</option>
                            <option value="Asturias" <?php echo e(old('province') == 'Asturias' ? 'selected' : ''); ?>>Asturias</option>
                            <option value="Ávila" <?php echo e(old('province') == 'Ávila' ? 'selected' : ''); ?>>Ávila</option>
                            <option value="Badajoz" <?php echo e(old('province') == 'Badajoz' ? 'selected' : ''); ?>>Badajoz</option>
                            <option value="Baleares" <?php echo e(old('province') == 'Baleares' ? 'selected' : ''); ?>>Baleares</option>
                            <option value="Barcelona" <?php echo e(old('province') == 'Barcelona' ? 'selected' : ''); ?>>Barcelona</option>
                            <option value="Burgos" <?php echo e(old('province') == 'Burgos' ? 'selected' : ''); ?>>Burgos</option>
                            <option value="Cáceres" <?php echo e(old('province') == 'Cáceres' ? 'selected' : ''); ?>>Cáceres</option>
                            <option value="Cádiz" <?php echo e(old('province') == 'Cádiz' ? 'selected' : ''); ?>>Cádiz</option>
                            <option value="Cantabria" <?php echo e(old('province') == 'Cantabria' ? 'selected' : ''); ?>>Cantabria</option>
                            <option value="Castellón" <?php echo e(old('province') == 'Castellón' ? 'selected' : ''); ?>>Castellón</option>
                            <option value="Ceuta" <?php echo e(old('province') == 'Ceuta' ? 'selected' : ''); ?>>Ceuta</option>
                            <option value="Ciudad Real" <?php echo e(old('province') == 'Ciudad Real' ? 'selected' : ''); ?>>Ciudad Real</option>
                            <option value="Córdoba" <?php echo e(old('province') == 'Córdoba' ? 'selected' : ''); ?>>Córdoba</option>
                            <option value="Cuenca" <?php echo e(old('province') == 'Cuenca' ? 'selected' : ''); ?>>Cuenca</option>
                            <option value="Gerona/Girona" <?php echo e(old('province') == 'Gerona/Girona' ? 'selected' : ''); ?>>Gerona/Girona</option>
                            <option value="Granada" <?php echo e(old('province') == 'Granada' ? 'selected' : ''); ?>>Granada</option>
                            <option value="Guadalajara" <?php echo e(old('province') == 'Guadalajara' ? 'selected' : ''); ?>>Guadalajara</option>
                            <option value="Guipúzcoa/Gipuzkoa" <?php echo e(old('province') == 'Guipúzcoa/Gipuzkoa' ? 'selected' : ''); ?>>Guipúzcoa/Gipuzkoa</option>
                            <option value="Huelva" <?php echo e(old('province') == 'Huelva' ? 'selected' : ''); ?>>Huelva</option>
                            <option value="Huesca" <?php echo e(old('province') == 'Huesca' ? 'selected' : ''); ?>>Huesca</option>
                            <option value="Jaén" <?php echo e(old('province') == 'Jaén' ? 'selected' : ''); ?>>Jaén</option>
                            <option value="La Coruña/A Coruña" <?php echo e(old('province') == 'La Coruña/A Coruña' ? 'selected' : ''); ?>>La Coruña/A Coruña</option>
                            <option value="La Rioja" <?php echo e(old('province') == 'La Rioja' ? 'selected' : ''); ?>>La Rioja</option>
                            <option value="Las Palmas" <?php echo e(old('province') == 'Las Palmas' ? 'selected' : ''); ?>>Las Palmas</option>
                            <option value="León" <?php echo e(old('province') == 'León' ? 'selected' : ''); ?>>León</option>
                            <option value="Lérida/Lleida" <?php echo e(old('province') == 'Lérida/Lleida' ? 'selected' : ''); ?>>Lérida/Lleida</option>
                            <option value="Lugo" <?php echo e(old('province') == 'Lugo' ? 'selected' : ''); ?>>Lugo</option>
                            <option value="Madrid" <?php echo e(old('province') == 'Madrid' ? 'selected' : ''); ?>>Madrid</option>
                            <option value="Málaga" <?php echo e(old('province') == 'Málaga' ? 'selected' : ''); ?>>Málaga</option>
                            <option value="Melilla" <?php echo e(old('province') == 'Melilla' ? 'selected' : ''); ?>>Melilla</option>
                            <option value="Murcia" <?php echo e(old('province') == 'Murcia' ? 'selected' : ''); ?>>Murcia</option>
                            <option value="Navarra" <?php echo e(old('province') == 'Navarra' ? 'selected' : ''); ?>>Navarra</option>
                            <option value="Orense/Ourense" <?php echo e(old('province') == 'Orense/Ourense' ? 'selected' : ''); ?>>Orense/Ourense</option>
                            <option value="Palencia" <?php echo e(old('province') == 'Palencia' ? 'selected' : ''); ?>>Palencia</option>
                            <option value="Pontevedra" <?php echo e(old('province') == 'Pontevedra' ? 'selected' : ''); ?>>Pontevedra</option>
                            <option value="Salamanca" <?php echo e(old('province') == 'Salamanca' ? 'selected' : ''); ?>>Salamanca</option>
                            <option value="Segovia" <?php echo e(old('province') == 'Segovia' ? 'selected' : ''); ?>>Segovia</option>
                            <option value="Sevilla" <?php echo e(old('province') == 'Sevilla' ? 'selected' : ''); ?>>Sevilla</option>
                            <option value="Soria" <?php echo e(old('province') == 'Soria' ? 'selected' : ''); ?>>Soria</option>
                            <option value="Tarragona" <?php echo e(old('province') == 'Tarragona' ? 'selected' : ''); ?>>Tarragona</option>
                            <option value="Tenerife" <?php echo e(old('province') == 'Tenerife' ? 'selected' : ''); ?>>Tenerife</option>
                            <option value="Teruel" <?php echo e(old('province') == 'Teruel' ? 'selected' : ''); ?>>Teruel</option>
                            <option value="Toledo" <?php echo e(old('province') == 'Toledo' ? 'selected' : ''); ?>>Toledo</option>
                            <option value="Valencia" <?php echo e(old('province') == 'Valencia' ? 'selected' : ''); ?>>Valencia</option>
                            <option value="Valladolid" <?php echo e(old('province') == 'Valladolid' ? 'selected' : ''); ?>>Valladolid</option>
                            <option value="Vizcaya/Bizkaia" <?php echo e(old('province') == 'Vizcaya/Bizkaia' ? 'selected' : ''); ?>>Vizcaya/Bizkaia</option>
                            <option value="Zamora" <?php echo e(old('province') == 'Zamora' ? 'selected' : ''); ?>>Zamora</option>
                            <option value="Zaragoza" <?php echo e(old('province') == 'Zaragoza' ? 'selected' : ''); ?>>Zaragoza</option>
                        </select>
                        <?php $__errorArgs = ['province'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="error">*<?php echo e($message); ?>*</div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    

                    <div class="form-group">
                        <label for="rol">Authority</label>
                        <select required name="authority" id="authority" class="form-control">
                            <option value="">Select Authority</option>
                            <?php if(Auth::user()->authority == 'root'): ?>
                            <option value="root" <?php echo e(old('authority') == 'root' ? 'selected' : ''); ?>>Root</option>
                            <option value="admin" <?php echo e(old('authority') == 'admin' ? 'selected' : ''); ?>>Admin</option>
                            <option value="user" <?php echo e(old('authority') == 'user' ? 'selected' : ''); ?>>User</option>  
                            <?php endif; ?>  
                            <?php if(Auth::user()->authority == 'admin'): ?>
                            <option value="admin" <?php echo e(old('authority') == 'admin' ? 'selected' : ''); ?>>Admin</option>
                            <option value="user" <?php echo e(old('authority') == 'user' ? 'selected' : ''); ?>>User</option>  
                            <?php endif; ?>                
                        </select>
                        <?php $__errorArgs = ['authority'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="error">*<?php echo e($message); ?>*</div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    

                    <div class="form-group">
                        <label for="avatar">Avatar</label> <br>
                        <input type="file" id="avatar" name="avatar" value="<?php echo e(old('avatar')); ?>">
                        <?php $__errorArgs = ['avatar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="error">*<?php echo e($message); ?>*</div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    

                    <div class="form-group">
                        <label for="description">Description</label>
                        <textarea class="form-control" id="description" name="description" rows="3"><?php echo e(old('description')); ?></textarea>
                        <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="error">*<?php echo e($message); ?>*</div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    

                    <button type="submit" class="btn  btn-primary">Submit</button>
                
                </form>
            </div>
        </div>
    </div>    
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Quini\Apache2020\htdocs\laraveles\WallapopApp\resources\views/backend/create.blade.php ENDPATH**/ ?>